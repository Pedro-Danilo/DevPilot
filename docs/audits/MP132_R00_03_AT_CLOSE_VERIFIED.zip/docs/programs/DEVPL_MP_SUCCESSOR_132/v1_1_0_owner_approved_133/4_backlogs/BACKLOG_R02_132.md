---
doc_id: DEVPL-MP-SUCCESSOR-132-BACKLOG_R02_132
title: "Backlog R2 — Product Definition y modelo local real"
version: "1.1.0"
status: "OWNER_APPROVED_PROGRAM"
baseline_commit: "8db5b44694abcced3231183e05731e732f5b8f24"
owner: "Owner DevPilot"
supersedes_program: "DEVPL_MP_SUCCESSOR_131 v1.0.0"
execution_authority: false
approval_revision: 1
approval_date: "2026-10-13"
approved_by: "Owner Ordóñez (instrucción explícita en conversación)"
approval_scope: "PROGRAMMATIC_PLANNING_ONLY"
owner_decision_ref: "DEVPL-MP-132-OWNER-APPROVAL-133"
---

# Backlog R2 — Product Definition y modelo local real

## Resultado y gate de ola

**Ola R2 — Product Definition y modelo local real.** Ver `0_program/02_ROADMAP_INDUSTRIAL_132.md` y `2_contratos/PROGRAM_DEPENDENCY_REGISTER_132.md` para dependencias. Cada fila es una capacidad **propuesta**, no una orden de implementación. Antes de tocar source se exige Audit-first, head y Owner approval.

## Ítems heredados v131 — preservados por ID, authority sucesora 132

| ID original estable | Prioridad | Resultado conservado | AC original — sujeto a clarificaciones 132 |
|---|---|---|---|
| MP131-R2-01 | P0 | Auditoría focal y contrato Product Definition D/L | Rutas ya existentes inventariadas; equivalencia determinística sin regresión; RAG source scopes correctos |
| MP131-R2-02 | P0 | Ollama local opt-in para Product Definition | Modelo local instalado y realmente llamado; salida estructurada validada; sin API key, sin cloud ni source writes |
| MP131-R2-03 | P1 | LM Studio local opt-in y paridad funcional acotada | Health, endpoint loopback, request, timeout, structured output, error y fallback medidos; D disponible offline |
| MP131-R2-04 | P0 | Selección/comparación D/L de Vision/Scope/Requirements | Candidates comparables en UI, origen+linaje, Owner decide; semantic RF gate y approvals antes de FROZEN |
| MP131-R2-05 | P0 | Pilot B B0–B1: greenfield, constraints, Product Definition | Workspace nuevo; Project Entry→Vision→Scope→Requirements FROZEN en UI; `operator_project_writes=0` |
| MP131-R2-06 | P1 | Fallas local real: desconexión, JSON malo, model unavailable | Sin cambios no autorizados ni doble candidate; fallback explícito/denegación; trazas sin secretos |

**Rebind v1.1:** Preservar el objetivo y criterio de aceptación de los ítems heredados, rebindeados al baseline/contratos 132 y sin prompts históricos ejecutables.

## Nuevas capacidades v1.1 asignadas a esta ola

| ID nuevo | Prioridad | Capacidad / entrega | AC verificable |
|---|---|---|---|
| MP132-R2-07 | P0 | Readiness de modelo local en Settings | SUPPORTED/HEALTHY/EVALUATED/ELIGIBLE separados; modelo real probado; no requiere API paga |
| MP132-R2-08 | P0 | Documentos Pre-code humanos persistentes | Vision/Scope/Requirements publicadas Markdown FROZEN, authority/hashes y portable |
| MP132-R2-09 | P1 | PESP, Coverage Gate y revisión semántica por primera app | No se exigen artefactos técnicos aún no decididos; gated business artifact quality |
| MP132-R2-10 | P1 | Home/Entry UX/Resume y trazabilidad de idea real | Owner entra necesidad y constraints, no stack hardcoded ni terminal |

## Reglas de estado y aceptación

- Estados por ítem: `PROPOSED`, `READY_AFTER_AUDIT`, `AUTHORIZED`, `IN_PROGRESS`, `BLOCKED`, `DONE_ACCEPTED`, `DEFERRED_WITH_REASON`, `NO_OP_ACCEPTED`. La versión 1.1 **no declara ninguna ejecución nueva**.
- Un ID tiene una sola ola propietaria. Dependencias a otra ola se referencian por ID, no se copian. Un auditor puede proponer `REUSE/NO-OP`; no se fuerza código.
- Una ola se cierra con gate, evidencia y Owner adjudication, no por sumar checkboxes ni terminar un listado de archivos. Tests de UI/sistema/modelo reales si esa ola promete verticalidad.
- No crear sprints/prompts por adelantado. El sprint futuro se rebindea a HEAD, incluye análisis de compatibilidad, presupuesto y allowlist exacta.


## Aclaración de autoridad Owner-133

Este backlog está **aprobado para priorización y planificación**. Sus ítems aún no equivalen a tareas ejecutables o aceptadas. La auditoría focal y una orden de alcance específica determinan `READY_AFTER_AUDIT` y `AUTHORIZED`. Los ítems R0 de ratificación se consideran satisfechos **documentalmente** por Owner-133, pero la publicación operativa de autoridad todavía debe verificarse en Windows.
