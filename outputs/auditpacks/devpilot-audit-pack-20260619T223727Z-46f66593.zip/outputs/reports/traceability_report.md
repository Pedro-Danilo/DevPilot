# DevPilot Evidence Report — traceability_report

## Metadata

- Report ID: `traceability_report`
- Command: `traceability report`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T21:27:02Z`
- Subject: `traceability:report`
- Project root: `.`
- JSON path: `outputs/reports/traceability_report.json`
- Markdown path: `outputs/reports/traceability_report.md`

## Message

Traceability report generated.

## Summary

- `acceptance_criteria_total`: 31
- `acceptance_criteria_with_requirement`: 27
- `acceptance_criteria_without_requirement`: 4
- `blocking_findings_total`: 0
- `coverage_percentages`: {'requirements_acceptance_criteria': 96.77, 'requirements_test_or_eval': 87.1, 'requirements_source_document': 100.0, 'acceptance_criteria_requirement': 87.1}
- `external_api_used`: False
- `gaps_total`: 6
- `links_total`: 173
- `mode`: report
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `requirements_total`: 31
- `requirements_with_acceptance_criteria`: 30
- `requirements_with_source_document`: 31
- `requirements_with_test_or_eval_evidence`: 27
- `requirements_without_acceptance_criteria`: 1
- `requirements_without_source_document`: 0
- `requirements_without_test_or_eval_evidence`: 4
- `scan_entities_total`: 322
- `scan_unique_entities_total`: 110
- `warnings_total`: 6

## Findings

- **INFO** `TRACEABILITY_REPORT_PASS`: Traceability report generated from explicit local evidence.
- **WARNING** `TRACEABILITY_REQUIREMENT_WITHOUT_TEST_EVIDENCE`: Requirement has no explicit test/eval evidence: FR-PLUS-009.
- **WARNING** `TRACEABILITY_REQUIREMENT_WITHOUT_ACCEPTANCE_CRITERIA`: Requirement has no explicit acceptance criterion: FR-POST-005.
- **WARNING** `TRACEABILITY_ACCEPTANCE_CRITERION_WITHOUT_REQUIREMENT`: Acceptance criterion has no explicit requirement: AC-GWT-001.
- **WARNING** `TRACEABILITY_ACCEPTANCE_CRITERION_WITHOUT_REQUIREMENT`: Acceptance criterion has no explicit requirement: AC-GWT-002.
- **WARNING** `TRACEABILITY_ACCEPTANCE_CRITERION_WITHOUT_REQUIREMENT`: Acceptance criterion has no explicit requirement: AC-GWT-004.
- **WARNING** `TRACEABILITY_ACCEPTANCE_CRITERION_WITHOUT_REQUIREMENT`: Acceptance criterion has no explicit requirement: AC-GWT-005.

## Report Metadata

- `action`: report
- `component`: TraceabilityEngine
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-26
