# DevPilot Evidence Report — repo_dependency_graph

## Metadata

- Report ID: `repo_dependency_graph`
- Command: `repo dependency-graph`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T20:14:13Z`
- Subject: `src/devpilot_core`
- Project root: `.`
- JSON path: `outputs/reports/repo_dependency_graph.json`
- Markdown path: `outputs/reports/repo_dependency_graph.md`

## Message

Python dependency graph generated in read-only mode.

## Summary

- `edges_total`: 1595
- `external_api_used`: False
- `external_imports_total`: 36
- `ignored_dirs`: []
- `max_files`: 5000
- `mutations_performed`: False
- `network_used`: False
- `nodes_total`: 195
- `preliminary`: True
- `root_package`: devpilot_core
- `syntax_error_files_total`: 0
- `target`: src/devpilot_core
- `truncated`: False

## Findings

- **INFO** `DEPENDENCY_GRAPH_PASS`: Python dependency graph generated in read-only mode.

## Report Metadata

- `component`: DependencyGraphBuilder
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-36
