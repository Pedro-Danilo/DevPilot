# DevPilot Evidence Report — git_diff_report

## Metadata

- Report ID: `git_diff_report`
- Command: `git diff-report`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T20:15:17Z`
- Subject: `.`
- Project root: `.`
- JSON path: `outputs/reports/git_diff_report.json`
- Markdown path: `outputs/reports/git_diff_report.md`

## Message

Git diff report collected in read-only mode.

## Summary

- `added_files`: 0
- `deleted_files`: 1
- `deletions_total`: 17017
- `external_api_used`: False
- `files_total`: 108
- `git_available`: True
- `high_risk_files`: 0
- `insertions_total`: 8893
- `is_git_repo`: True
- `max_files`: 200
- `medium_risk_files`: 0
- `modified_files`: 88
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `renamed_files`: 0
- `staged_files`: 0
- `truncated`: False
- `unstaged_files`: 89
- `untracked_files`: 19

## Findings

- **INFO** `GIT_DIFF_REPORT_READ_ONLY_PASS`: Git diff report was collected using read-only commands.

## Report Metadata

- `action`: diff-report
- `component`: GitAdapterV2
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-35
