# DevPilot Evidence Report — backup_create

## Metadata

- Report ID: `backup_create`
- Command: `backup create`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T20:13:32Z`
- Subject: `backup:create:backup-20260619T201332Z-7cc08f6b`
- Project root: `.`
- JSON path: `outputs/reports/backup_create.json`
- Markdown path: `outputs/reports/backup_create.md`

## Message

Local backup plan generated.

## Summary

- `backup_created`: False
- `backup_dir`: .devpilot/backups
- `backup_id`: backup-20260619T201332Z-7cc08f6b
- `backup_manifest`: .devpilot/backups/backup-20260619T201332Z-7cc08f6b.manifest.json
- `backup_zip`: .devpilot/backups/backup-20260619T201332Z-7cc08f6b.zip
- `caches_excluded_by_default`: True
- `candidate_files_total`: 10
- `deploys_artifacts`: False
- `dry_run`: True
- `execute_requested`: False
- `external_api_used`: False
- `forbidden_defaults_excluded`: True
- `git_dir_excluded_by_default`: True
- `git_tagging_performed`: False
- `included_files_total`: 10
- `missing_files_total`: 0
- `network_used`: False
- `outputs_excluded_by_default`: True
- `preliminary`: True
- `publishes_artifacts`: False
- `redactions_total`: 10
- `schema_version`: 1.0.0
- `secrets_redacted_by_default`: True
- `source_mutations_performed`: False
- `sqlite_state_included`: True
- `venv_excluded_by_default`: True

## Findings

- **WARNING** `BACKUP_SECRET_REDACTED` — `.devpilot/providers.yaml`: SecretGuard redacted secret-like textual content before backup packaging.
- **WARNING** `BACKUP_SECRET_REDACTED` — `.devpilot/providers.yaml.example`: SecretGuard redacted secret-like textual content before backup packaging.
- **INFO** `BACKUP_DRY_RUN`: Backup create ran in dry-run mode; no backup artifact was written.

## Report Metadata

- `backup_id`: backup-20260619T201332Z-7cc08f6b
- `component`: BackupCreate
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-83
