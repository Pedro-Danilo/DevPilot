# DevPilot Evidence Report — release_manifest

## Metadata

- Report ID: `release_manifest`
- Command: `release manifest`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T19:06:19Z`
- Subject: `release:0.1.0`
- Project root: `.`
- JSON path: `outputs/reports/release_manifest.json`
- Markdown path: `outputs/reports/release_manifest.md`

## Message

Release manifest generated.

## Summary

- `channel`: local-candidate
- `components_total`: 8
- `dry_run`: True
- `evidence_commands_total`: 3
- `expected_artifacts_total`: 18
- `external_api_used`: False
- `git_metadata_available`: True
- `is_git_repo`: True
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `release_id`: DEVPL-0.1.0
- `release_status`: candidate-local
- `reports_written`: False
- `schema_version`: 1.0.0
- `source_mutations_performed`: False
- `valid_version`: True
- `version`: 0.1.0

## Findings

- **INFO** `RELEASE_MANIFEST_CREATED`: Release manifest metadata was created without network, publication or source mutation.

## Report Metadata

- `component`: ReleaseManifest
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-77
- `version`: 0.1.0
