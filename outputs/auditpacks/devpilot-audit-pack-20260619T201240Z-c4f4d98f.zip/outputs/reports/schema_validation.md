# DevPilot Evidence Report — schema_validation

## Metadata

- Report ID: `schema_validation`
- Command: `schema validate`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T19:21:24Z`
- Subject: `C:/Users/Pedro/AppData/Local/Temp/pytest-of-Pedro/pytest-366/test_schema_validate_cli_write0/application_response.json`
- Project root: `.`
- JSON path: `outputs/reports/schema_validation.json`
- Markdown path: `outputs/reports/schema_validation.md`

## Message

Schema validation passed.

## Summary

- `errors_total`: 0
- `external_api_used`: False
- `findings_total`: 1
- `instance`: C:/Users/Pedro/AppData/Local/Temp/pytest-of-Pedro/pytest-366/test_schema_validate_cli_write0/application_response.json
- `jsonschema_version`: 4.26.0
- `network_used`: False
- `preliminary`: True
- `schema`: docs/schemas/application_response.schema.json
- `schema_id`: SCHEMA-DEVPL-APPLICATION-RESPONSE-V1
- `schema_title`: DevPilot ApplicationResponse v1
- `valid`: True
- `validator`: jsonschema

## Findings

- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.

## Report Metadata

- `component`: SchemaValidator
- `contract`: EvidenceReport
- `schema`: docs/schemas/application_response.schema.json
- `sprint`: FUNC-SPRINT-22
