# DevPilot Evidence Report — upgrade_check

## Metadata

- Report ID: `upgrade_check`
- Command: `upgrade check`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T18:40:57Z`
- Subject: `upgrade:check:0.1.0`
- Project root: `.`
- JSON path: `outputs/reports/upgrade_check.json`
- Markdown path: `outputs/reports/upgrade_check.md`

## Message

Local upgrade readiness plan generated.

## Summary

- `checks_passed`: 6
- `checks_total`: 6
- `checks_warning`: 0
- `current_version`: 0.1.0
- `deploys_artifacts`: False
- `dry_run_default`: True
- `external_api_used`: False
- `generated_at_utc`: 2026-06-19T18:40:57+00:00
- `git_tagging_performed`: False
- `latest_backup_manifest`: .devpilot/backups/backup-20260617T230617Z-78ac8d90.manifest.json
- `missing_required_total`: 0
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `publishes_artifacts`: False
- `rollback_path_documented`: True
- `schema_version`: 1.0.0
- `target_version`: 0.1.0
- `upgrade_ready`: True

## Findings

No findings.

## Report Metadata

- `component`: UpgradeCheck
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-83
- `target_version`: 0.1.0
