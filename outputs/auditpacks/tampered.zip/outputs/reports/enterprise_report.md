# DevPilot Evidence Report — enterprise_report

## Metadata

- Report ID: `enterprise_report`
- Command: `enterprise report`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T22:38:06Z`
- Subject: `enterprise:local-report`
- Project root: `.`
- JSON path: `outputs/reports/enterprise_report.json`
- Markdown path: `outputs/reports/enterprise_report.md`

## Message

Enterprise report built locally in read-only mode.

## Summary

- `cloud_control_plane_enabled`: False
- `compliance_packs_total`: 1
- `enterprise_report_read_only`: True
- `external_api_used`: False
- `gaps_total`: 0
- `latest_sprint_manifest`: functional_sprint_99_manifest.json
- `local_first`: True
- `miasi_policy_rules_total`: 93
- `miasi_tools_total`: 94
- `mutations_performed`: False
- `network_used`: False
- `policy_engine_replaced`: False
- `policy_engine_used`: True
- `preliminary`: True
- `remote_execution_used`: False
- `remote_runner_enabled`: False
- `schemas_total`: 24
- `source_mutations_performed`: False
- `sprint_manifests_total`: 100
- `workspaces_total`: 1

## Findings

- **INFO** `ENTERPRISE_REPORT_PASS`: Enterprise report aggregated local governance evidence without remote execution.

## Report Metadata

- `component`: EnterpriseReportBuilder
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-98
