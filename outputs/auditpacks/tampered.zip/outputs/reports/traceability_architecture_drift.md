# DevPilot Evidence Report — traceability_architecture_drift

## Metadata

- Report ID: `traceability_architecture_drift`
- Command: `traceability architecture-drift`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-20T15:03:04Z`
- Subject: `traceability:architecture-drift`
- Project root: `.`
- JSON path: `outputs/reports/traceability_architecture_drift.json`
- Markdown path: `outputs/reports/traceability_architecture_drift.md`

## Message

Architecture/code drift check completed.

## Summary

- `architecture_docs_existing`: 3
- `architecture_docs_total`: 3
- `blocking_findings_total`: 0
- `drift_detected`: True
- `external_api_used`: False
- `findings_total`: 4
- `modules_documented`: 39
- `modules_total`: 42
- `modules_undocumented`: 3
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `warnings_total`: 3

## Findings

- **INFO** `ARCHITECTURE_DRIFT_CHECK_COMPLETED`: Architecture/code drift check completed with non-destructive findings.
- **WARNING** `ARCHITECTURE_DRIFT_CODE_MODULE_UNDOCUMENTED` — `src/devpilot_core/auditpack`: Top-level DevPilot module is not explicitly represented in architecture docs: auditpack.
- **WARNING** `ARCHITECTURE_DRIFT_CODE_MODULE_UNDOCUMENTED` — `src/devpilot_core/compliance`: Top-level DevPilot module is not explicitly represented in architecture docs: compliance.
- **WARNING** `ARCHITECTURE_DRIFT_CODE_MODULE_UNDOCUMENTED` — `src/devpilot_core/errors.py`: Top-level DevPilot module is not explicitly represented in architecture docs: errors.

## Report Metadata

- `component`: ArchitectureDriftDetector
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-27
