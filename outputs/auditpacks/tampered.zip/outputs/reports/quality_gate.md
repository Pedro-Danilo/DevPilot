# DevPilot Evidence Report — quality_gate

## Metadata

- Report ID: `quality_gate`
- Command: `quality-gate run`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T23:02:09Z`
- Subject: `release:quality-gate`
- Project root: `.`
- JSON path: `outputs/reports/quality_gate.json`
- Markdown path: `outputs/reports/quality_gate.md`

## Message

Quality gate passed.

## Summary

- `blocking_findings_total`: 0
- `critical_subgates_failed`: 0
- `dry_run`: True
- `external_api_used`: False
- `findings_total`: 17
- `include_pytest`: False
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `profile`: fast
- `pytest_timeout_seconds`: None
- `reports_written`: False
- `source_mutations_performed`: False
- `subgates_failed`: 0
- `subgates_passed`: 5
- `subgates_total`: 5
- `warnings_total`: 12

## Findings

- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/01_requirements/use_cases.md`: Recommended section is missing for profile 'use-cases': criterios
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/02_architecture/c4_context.md`: Recommended section is missing for profile 'c4-context': mermaid
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/02_architecture/c4_container.md`: Recommended section is missing for profile 'c4-container': mermaid
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/03_security/security_threat_model.md`: Recommended section is missing for profile 'security-threat-model': miasi
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/04_quality/test_strategy.md`: Recommended section is missing for profile 'test-strategy': coverage
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/06_miasi/agent_card.md`: Recommended section is missing for profile 'miasi-agent-card': herramientas
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/06_miasi/tool_card.md`: Recommended section is missing for profile 'miasi-tool-card': aprobación
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/checklists/checklist_pre_code.md`: Recommended section is missing for profile 'generic-markdown': estado
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_audit_report.md`: Recommended section is missing for profile 'generic-markdown': propósito
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_audit_report.md`: Recommended section is missing for profile 'generic-markdown': estado
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_baseline_decision.md`: Recommended section is missing for profile 'generic-markdown': propósito
- **WARNING** `QUALITY_GATE_READINESS_STRICT_ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_baseline_decision.md`: Recommended section is missing for profile 'generic-markdown': estado
- **INFO** `QUALITY_GATE_MIASI_VALIDATE_MIASI_POLICY_MATRIX_PASS`: Policy Matrix coverage passed.
- **INFO** `QUALITY_GATE_MIASI_VALIDATE_MIASI_TOOL_REGISTRY_PASS`: Tool Registry validation passed.
- **INFO** `QUALITY_GATE_MIASI_VALIDATE_MIASI_AGENT_REGISTRY_PASS`: Agent Registry validation passed.
- **INFO** `QUALITY_GATE_EVAL_HARNESS_READY_EVAL_HARNESS_READY`: Evaluation fixture is parseable and declares documentation cases.
- **INFO** `QUALITY_GATE_APP_CONTRACT_APP_CONTRACT_V2_PASS`: ApplicationService v2 exposes domain facades plus secured local API route contracts, Web UI viewers, Approval Center, Settings UI and Fase F visual MVP closure.

## Report Metadata

- `component`: QualityGate
- `contract`: EvidenceReport
- `profile`: fast
- `sprint`: FUNC-SPRINT-75
