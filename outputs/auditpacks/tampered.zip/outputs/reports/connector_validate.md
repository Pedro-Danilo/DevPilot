# DevPilot Evidence Report — connector_validate

## Metadata

- Report ID: `connector_validate`
- Command: `connector validate`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T22:38:04Z`
- Subject: `.devpilot/connectors/connector_registry.json`
- Project root: `.`
- JSON path: `outputs/reports/connector_validate.json`
- Markdown path: `outputs/reports/connector_validate.md`

## Message

Connector Registry validation passed.

## Summary

- `connector_calls_enabled`: False
- `connector_execution_performed`: False
- `connectors_total`: 4
- `deny_by_default_required`: True
- `enabled_by_default_total`: 0
- `execution_enabled_total`: 0
- `external_api_enabled_total`: 0
- `external_api_used`: False
- `implemented_connectors_total`: 1
- `mcp_client_implemented`: False
- `mcp_enabled_by_default`: False
- `mcp_runtime_enabled`: False
- `mcp_server_implemented`: False
- `network_enabled_total`: 0
- `network_used`: False
- `path_allowed`: True
- `path_guard_used`: True
- `policy_rules_missing_total`: 0
- `preliminary`: True
- `redactions_total`: 0
- `registry_path`: .devpilot/connectors/connector_registry.json
- `schema_path`: docs/schemas/connector_registry.schema.json
- `schema_valid`: True
- `schema_version`: 1.0.0
- `secret_guard_used`: True
- `status_counts`: {'disabled': 2, 'experimental': 0, 'implemented': 1, 'planned': 1}

## Findings

- **INFO** `CONNECTOR_REGISTRY_VALIDATED`: Connector Registry is structurally valid and keeps MCP/connectors deny-by-default.

## Report Metadata

- `component`: ConnectorRegistry
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-88
