# DevPilot Evidence Report — schema_validate_miasi

## Metadata

- Report ID: `schema_validate_miasi`
- Command: `schema validate-miasi`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T22:38:04Z`
- Subject: `.devpilot/miasi`
- Project root: `.`
- JSON path: `outputs/reports/schema_validate_miasi.json`
- Markdown path: `outputs/reports/schema_validate_miasi.md`

## Message

MIASI registries passed structural schema validation.

## Summary

- `contract_group`: MIASI
- `contracts_total`: 3
- `preliminary`: True
- `scope`: all
- `subject`: .devpilot/miasi
- `validations_failed`: 0
- `validations_passed`: 3
- `validations_total`: 3

## Findings

- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.

## Report Metadata

- `component`: BuiltinContractValidator
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-23
