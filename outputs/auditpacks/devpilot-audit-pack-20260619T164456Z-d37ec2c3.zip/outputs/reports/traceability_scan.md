# DevPilot Evidence Report — traceability_scan

## Metadata

- Report ID: `traceability_scan`
- Command: `traceability scan`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T16:03:10Z`
- Subject: `traceability:scan`
- Project root: `.`
- JSON path: `outputs/reports/traceability_scan.json`
- Markdown path: `outputs/reports/traceability_scan.md`

## Message

Traceability scan completed.

## Summary

- `duplicate_entity_ids_total`: 83
- `entities_total`: 319
- `entity_type_counts`: {'acceptance_criterion': 63, 'adr': 75, 'functional_requirement': 142, 'requirement': 4, 'test': 1, 'user_story': 34}
- `inferred_links`: False
- `invalid_tokens_total`: 44
- `links_total`: 0
- `preliminary`: True
- `source_paths_total`: 117
- `unique_entities_total`: 108

## Findings

- **INFO** `TRACEABILITY_SCAN_PASS`: Traceability entity extraction completed without blocking findings.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_10_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_11_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_12_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_14_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_15_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_16_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_17_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_18_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_22_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_22_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_45_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_45_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_46_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_47_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_48_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_49_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_50_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_51_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_52_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_53_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_54_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_55_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_56_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_56_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_56_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_57_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_58_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_59_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_60_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_61_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_62_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_63_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_64_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_64_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_64_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_65_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_67_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_68_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_74_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_74_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_82_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_82_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_85_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_ID_INVALID` — `docs/functional_sprint_85_manifest.json`: Malformed traceability ID-like token detected.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-GWT-003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-002.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-005.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-006.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-007.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-008.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-009.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-010.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-011.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-012.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-MVP-013.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-002.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-005.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-006.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-007.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-008.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-PLUS-009.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-POST-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-POST-002.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-POST-003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: AC-POST-004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0002.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0005.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0006.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0007.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0008.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0009.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0010.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0011.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0012.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0013.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0014.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0015.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: ADR-0016.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-002.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-005.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-006.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-007.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-008.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-009.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-010.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-011.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-012.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-013.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-014.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-015.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-MVP-016.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-002.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-005.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-006.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-007.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-008.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-009.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-PLUS-010.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-POST-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-POST-002.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-POST-003.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-POST-004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: FR-POST-005.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-MVP-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-MVP-004.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-MVP-006.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-MVP-010.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-MVP-011.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-PLUS-005.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-PLUS-008.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-POST-001.
- **WARNING** `TRACEABILITY_ENTITY_DUPLICATE`: Traceability ID appears more than once: US-POST-002.

## Report Metadata

- `component`: MarkdownTraceabilityExtractor
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-25
