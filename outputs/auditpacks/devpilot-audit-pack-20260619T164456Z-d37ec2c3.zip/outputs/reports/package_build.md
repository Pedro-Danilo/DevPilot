# DevPilot Evidence Report — package_build

## Metadata

- Report ID: `package_build`
- Command: `package build`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T15:45:01Z`
- Subject: `package:all:0.1.0`
- Project root: `.`
- JSON path: `outputs/reports/package_build.json`
- Markdown path: `outputs/reports/package_build.md`

## Message

Package build completed.

## Summary

- `artifacts_written_total`: 3
- `deploy_performed`: False
- `dry_run`: False
- `excluded_files_total`: 163378
- `execute`: True
- `external_api_used`: False
- `included_files_total`: 1166
- `kind`: all
- `network_used`: False
- `outputs_total`: 3
- `preliminary`: True
- `publish_performed`: False
- `python_package_supported`: True
- `repo_zip_supported`: True
- `reports_written`: False
- `schema_version`: 1.0.0
- `source_mutations_performed`: False
- `valid_version`: True
- `version`: 0.1.0

## Findings

- **INFO** `PACKAGE_BUILD_ARTIFACTS_CREATED`: Package build produced a clean local build plan and wrote local artifacts.

## Report Metadata

- `component`: PackageBuild
- `contract`: EvidenceReport
- `kind`: all
- `sprint`: FUNC-SPRINT-79
- `version`: 0.1.0
