# DevPilot Evidence Report — checklist_pre_code

## Metadata

- Report ID: `checklist_pre_code`
- Command: `checklist-pre-code`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T16:02:39Z`
- Project root: `.`
- JSON path: `outputs/reports/checklist_pre_code.json`
- Markdown path: `outputs/reports/checklist_pre_code.md`

## Message

Pre-code checklist gate passed.

## Summary

- `mandatory_artifacts_present`: 23
- `mandatory_artifacts_total`: 23
- `mandatory_rows`: 39
- `pass_rows`: 39
- `total_rows`: 47

## Findings

No findings.

## Report Metadata

- `contract`: EvidenceReport
