# DevPilot Evidence Report — release_sbom

## Metadata

- Report ID: `release_sbom`
- Command: `release sbom`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T15:48:19Z`
- Subject: `release:0.1.0:sbom`
- Project root: `.`
- JSON path: `outputs/reports/release_sbom.json`
- Markdown path: `outputs/reports/release_sbom.md`

## Message

Release SBOM baseline generated.

## Summary

- `channel`: local-candidate
- `components_total`: 72
- `cyclonedx_compatible`: True
- `cyclonedx_components_total`: 72
- `dev_dependencies_declared`: True
- `external_api_used`: False
- `license_scan_performed`: False
- `mutations_performed`: False
- `network_used`: False
- `node_direct_dependencies_total`: 2
- `node_locked_components_total`: 64
- `preliminary`: True
- `python_build_dependencies_total`: 1
- `python_dev_dependencies_total`: 4
- `python_optional_dependencies_total`: 6
- `python_runtime_dependencies_total`: 1
- `release_id`: DEVPL-0.1.0
- `reports_written`: False
- `runtime_dependencies_declared`: True
- `sbom_id`: SBOM-devpilot-local-0.1.0
- `schema_version`: 1.0.0
- `slsa_baseline_declared`: True
- `source_mutations_performed`: False
- `version`: 0.1.0
- `vulnerability_scan_performed`: False

## Findings

- **INFO** `SBOM_BASELINE_CREATED`: Local SBOM baseline was generated from project manifests without network, external APIs or source mutation.

## Report Metadata

- `component`: ReleaseSbom
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-80
- `version`: 0.1.0
