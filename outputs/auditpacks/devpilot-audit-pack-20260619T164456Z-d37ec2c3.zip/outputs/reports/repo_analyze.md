# DevPilot Evidence Report — repo_analyze

## Metadata

- Report ID: `repo_analyze`
- Command: `repo analyze`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T15:52:48Z`
- Subject: `.`
- Project root: `.`
- JSON path: `outputs/reports/repo_analyze.json`
- Markdown path: `outputs/reports/repo_analyze.md`

## Message

Repository analysis completed in read-only mode.

## Summary

- `dependency`: {'nodes_total': 186, 'edges_total': 1522, 'external_imports_total': 36, 'syntax_error_files_total': 0}
- `external_api_used`: False
- `git`: {'is_git_repo': True, 'branch': 'main', 'counts': {'entries_total': 151, 'modified': 88, 'added': 0, 'deleted': 1, 'renamed': 0, 'untracked': 62, 'staged': 0}, 'git_available': True}
- `health_score`: 60
- `hotspots_total`: 20
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `rating`: risk
- `risk_counts`: {'block': 0, 'fail': 0, 'warning': 29, 'info': 0}
- `sections_summary`: {'files_total': 1148, 'src_tests_ratio': 1.057, 'docs_to_source_ratio': 2.134}
- `target`: .

## Findings

- **WARNING** `REPO_ANALYZER_LARGE_FILES`: Large files were detected; review maintainability and report size impact.
- **WARNING** `REPO_ANALYZER_MODULES_WITHOUT_NEAR_TESTS`: Some modules do not have obvious nearby/direct tests by heuristic.
- **WARNING** `REPO_ANALYZER_GIT_WORKTREE_CHANGES`: Working tree changes are present during analysis.
- **WARNING** `REPO_ANALYZER_UPSTREAM_GIT_UNTRACKED_FILES_PRESENT`: Upstream git finding: Untracked files are present.
- **WARNING** `REPO_ANALYZER_UPSTREAM_GIT_WORKTREE_CHANGES_PRESENT`: Upstream git finding: Working tree changes are present.

## Report Metadata

- `component`: RepoAnalyzer
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-37
