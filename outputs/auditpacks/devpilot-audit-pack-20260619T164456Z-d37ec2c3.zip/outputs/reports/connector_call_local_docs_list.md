# DevPilot Evidence Report — connector_call_local_docs_list

## Metadata

- Report ID: `connector_call_local_docs_list`
- Command: `connector call`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T15:24:13Z`
- Subject: `local-docs:list`
- Project root: `.`
- JSON path: `outputs/reports/connector_call_local_docs_list.json`
- Markdown path: `outputs/reports/connector_call_local_docs_list.md`

## Message

Connector call completed in governed read-only dry-run mode.

## Summary

- `connector_execution_performed`: False
- `connector_id`: local.docs
- `connector_status`: implemented
- `dry_run`: True
- `external_api_used`: False
- `items_total`: 20
- `limit`: 20
- `mcp_client_used`: False
- `mcp_server_used`: False
- `network_used`: False
- `operation_id`: list_sources
- `operation_status`: implemented
- `policy_allowed`: True
- `policy_checked`: True
- `preliminary`: True
- `read_only`: True
- `registry_valid`: True
- `remote_execution_used`: False
- `schema_version`: 1.0.0
- `shell_used`: False
- `sources_total`: 20
- `trace_event_emitted`: True

## Findings

- **INFO** `CONNECTOR_CALL_DRY_RUN_READ_ONLY`: Connector call passed PolicyEngine and returned local read-only evidence.

## Report Metadata

- `component`: ConnectorAdapter
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-89
