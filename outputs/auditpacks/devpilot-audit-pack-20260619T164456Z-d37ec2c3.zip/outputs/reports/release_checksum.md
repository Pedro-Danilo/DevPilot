# DevPilot Evidence Report — release_checksum

## Metadata

- Report ID: `release_checksum`
- Command: `release checksum`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T15:48:23Z`
- Subject: `release:0.1.0:checksum`
- Project root: `.`
- JSON path: `outputs/reports/release_checksum.json`
- Markdown path: `outputs/reports/release_checksum.md`

## Message

Release artifact checksum generated.

## Summary

- `artifact`: dist/release/test-devpilot-release.zip
- `artifact_exists`: True
- `artifact_kind`: zip
- `artifact_size_bytes`: 41007
- `deploy_performed`: False
- `external_api_used`: False
- `git_tagging_performed`: False
- `network_used`: False
- `preliminary`: True
- `publish_performed`: False
- `reports_written`: False
- `schema_version`: 1.0.0
- `sha256`: 370ba24b237a0116169eede949d1de624ba0f9ee0c8ded5a469c108195f50ca7
- `sha256_generated`: True
- `source_mutations_performed`: False
- `version`: 0.1.0

## Findings

- **INFO** `RELEASE_CHECKSUM_CREATED`: SHA256 checksum was generated for a real local release artifact.

## Report Metadata

- `component`: ReleaseChecksum
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-81
- `version`: 0.1.0
