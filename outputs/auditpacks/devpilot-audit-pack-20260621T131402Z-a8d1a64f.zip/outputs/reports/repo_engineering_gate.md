# DevPilot Evidence Report — repo_engineering_gate

## Metadata

- Report ID: `repo_engineering_gate`
- Command: `repo engineering-gate`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-12T15:05:21Z`
- Subject: `.`
- Project root: `.`
- JSON path: `outputs/reports/repo_engineering_gate.json`
- Markdown path: `outputs/reports/repo_engineering_gate.md`

## Message

Repository engineering gate passed.

## Summary

- `blocking_findings`: 0
- `components_failed`: 0
- `components_passed`: 8
- `components_total`: 8
- `external_api_used`: False
- `failing_findings`: 0
- `findings_total`: 61
- `git_write_used`: False
- `mutations_performed`: False
- `network_used`: False
- `patch_applied_to_productive_workspace`: False
- `phase_c_status`: closed
- `preliminary`: True
- `profile`: full
- `ready_for_phase_d_initial`: True
- `refactor_applied_to_productive_workspace`: False
- `status`: PASS
- `target`: .
- `warnings_total`: 43

## Findings

- **INFO** `ENGINEERING_GATE_GIT_STATUS_GIT_STATUS_READ_ONLY_PASS`: Git status was collected using read-only commands.
- **WARNING** `ENGINEERING_GATE_GIT_STATUS_GIT_UNTRACKED_FILES_PRESENT`: Untracked files are present.
- **WARNING** `ENGINEERING_GATE_GIT_STATUS_GIT_WORKTREE_CHANGES_PRESENT`: Working tree changes are present.
- **INFO** `ENGINEERING_GATE_DEPENDENCY_GRAPH_DEPENDENCY_GRAPH_PASS`: Python dependency graph generated in read-only mode.
- **WARNING** `ENGINEERING_GATE_REPO_ANALYZER_REPO_ANALYZER_LARGE_FILES`: Large files were detected; review maintainability and report size impact.
- **WARNING** `ENGINEERING_GATE_REPO_ANALYZER_REPO_ANALYZER_TODO_MARKERS`: TODO/FIXME/HACK markers were detected in bounded text scan.
- **WARNING** `ENGINEERING_GATE_REPO_ANALYZER_REPO_ANALYZER_MODULES_WITHOUT_NEAR_TESTS`: Some modules do not have obvious nearby/direct tests by heuristic.
- **WARNING** `ENGINEERING_GATE_REPO_ANALYZER_REPO_ANALYZER_GIT_WORKTREE_CHANGES`: Working tree changes are present during analysis.
- **WARNING** `ENGINEERING_GATE_REPO_ANALYZER_REPO_ANALYZER_UPSTREAM_GIT_UNTRACKED_FILES_PRESENT`: Upstream git finding: Untracked files are present.
- **WARNING** `ENGINEERING_GATE_REPO_ANALYZER_REPO_ANALYZER_UPSTREAM_GIT_WORKTREE_CHANGES_PRESENT`: Upstream git finding: Working tree changes are present.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: AgentRuntime documental.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Artifact.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Checklist Validator.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: DTOs ApplicationRequest/Response.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Eval Harness offline.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: EventLogger JSONL.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Filesystem/docs.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Frontmatter Validator.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Git local.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: GitAdapter + RepoInventory.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: LocalStore SQLite v0.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: MIASI Registry Validator.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Model provider layer.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: ModelAdapter Router.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Policy Engine + Guards.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Readiness Gate.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/changes`: Code module has no evident architectural reference: changes.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/errors.py`: Code module has no evident architectural reference: errors.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/execution`: Code module has no evident architectural reference: execution.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/sandbox`: Code module has no evident architectural reference: sandbox.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/schemas`: Code module has no evident architectural reference: schemas.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/security`: Code module has no evident architectural reference: security.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/traceability`: Code module has no evident architectural reference: traceability.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/review`: Documented component and code module only match heuristically: Patch/Code Review dry-run -> review.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/store`: Documented component and code module only match heuristically: SQLite LocalStore -> store.
- **WARNING** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/refactor`: Documented component and code module only match heuristically: Safe Refactor Planner -> refactor.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Desktop UI.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Desktop UI.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: External APIs.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: External LLM APIs.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: MCP/API tools.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Ollama/LM Studio clients.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Patch apply sandbox.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Refactor execution.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Web UI/API.
- **INFO** `ENGINEERING_GATE_ARCHITECTURE_DRIFT_ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Web UI/API.
- **INFO** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_POLICY_POLICY_PASS`: PolicyEngine allowed the simulated request.
- **INFO** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_POLICY_POLICY_PASS`: PolicyEngine allowed the simulated request.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_LARGE_FILES`: Large files were detected; review maintainability and report size impact.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_TODO_MARKERS`: TODO/FIXME/HACK markers were detected in bounded text scan.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_MODULES_WITHOUT_NEAR_TESTS`: Some modules do not have obvious nearby/direct tests by heuristic.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_GIT_WORKTREE_CHANGES`: Working tree changes are present during analysis.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_UPSTREAM_GIT_UNTRACKED_FILES_PRESENT`: Upstream git finding: Untracked files are present.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_UPSTREAM_GIT_WORKTREE_CHANGES_PRESENT`: Upstream git finding: Working tree changes are present.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_CODE_REVIEW_CODE_REVIEW_TODO` — `src/devpilot_core/repo/analyzer.py`: TODO/FIXME marker detected.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_CODE_REVIEW_CODE_REVIEW_TODO` — `src/devpilot_core/repo/analyzer.py`: TODO/FIXME marker detected.
- **WARNING** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_CODE_REVIEW_CODE_REVIEW_TODO` — `src/devpilot_core/repo/analyzer.py`: TODO/FIXME marker detected.
- **INFO** `ENGINEERING_GATE_REPO_QUALITY_GATE_QUALITY_GATE_PATCH_REVIEW_QUALITY_GATE_PATCH_REVIEW_SKIPPED`: Patch review skipped: no patch supplied.
- **INFO** `ENGINEERING_GATE_MIASI_PHASE_C_ENGINEERING_GATE_MIASI_PASS`: Phase C MIASI tools, policies and approval gates are declared.
- **INFO** `ENGINEERING_GATE_PHASE_C_DOCUMENTS_ENGINEERING_GATE_PHASE_C_DOCS_PASS`: Phase C engineering documents and manifests are present.
- **INFO** `ENGINEERING_GATE_RUNTIME_INVARIANTS_ENGINEERING_GATE_RUNTIME_INVARIANTS_PASS`: Runtime artifact exclusions and sandbox modules are present.

## Report Metadata

- `component`: RepoEngineeringGate
- `contract`: EvidenceReport
- `profile`: full
- `sprint`: FUNC-SPRINT-44
