# DevPilot Evidence Report — agent_session_inspect_agsess_dc263dfb26234537aa0d58e434db23a7

## Metadata

- Report ID: `agent_session_inspect_agsess_dc263dfb26234537aa0d58e434db23a7`
- Command: `agent session inspect`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-18T23:39:25Z`
- Subject: `agsess_dc263dfb26234537aa0d58e434db23a7`
- Project root: `.`
- JSON path: `outputs/reports/agent_session_inspect_agsess_dc263dfb26234537aa0d58e434db23a7.json`
- Markdown path: `outputs/reports/agent_session_inspect_agsess_dc263dfb26234537aa0d58e434db23a7.md`

## Message

Agent session inspection passed.

## Summary

- `agents_total`: 1
- `events_returned`: 2
- `events_total`: 2
- `local_only`: True
- `localstore_projection_used`: True
- `memory_items_total`: 2
- `rag_enabled`: False
- `raw_outputs_stored`: False
- `raw_prompts_stored`: False
- `redaction_applied`: True
- `semantic_memory_enabled`: False
- `session_found`: True
- `storage_path`: .devpilot/agent_sessions/agsess_dc263dfb26234537aa0d58e434db23a7.json
- `tracestore_compatible`: True

## Findings

No findings.

## Report Metadata

- `component`: AgentSession
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-86
