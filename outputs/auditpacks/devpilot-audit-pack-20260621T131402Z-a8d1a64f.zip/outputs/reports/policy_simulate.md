# DevPilot Evidence Report — policy_simulate

## Metadata

- Report ID: `policy_simulate`
- Command: `policy simulate`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-11T12:12:32Z`
- Subject: `APPROVAL-C7A78CE80E45`
- Project root: `.`
- JSON path: `outputs/reports/policy_simulate.json`
- Markdown path: `outputs/reports/policy_simulate.md`

## Message

Policy check passed.

## Summary

- `allowed`: True
- `approval_required`: True
- `approval_valid`: True
- `blocked`: False
- `decisions_total`: 4
- `denied`: False
- `guards`: ['ApprovalPolicyChecker', 'CostGuard', 'PathGuard', 'SecretGuard']
- `warnings`: 0

## Findings

- **INFO** `POLICY_PASS`: PolicyEngine allowed the simulated request.

## Report Metadata

- `approval_binding`: True
- `component`: PolicyEngine
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-30
