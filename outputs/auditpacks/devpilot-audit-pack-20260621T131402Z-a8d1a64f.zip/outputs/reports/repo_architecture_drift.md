# DevPilot Evidence Report — repo_architecture_drift

## Metadata

- Report ID: `repo_architecture_drift`
- Command: `repo architecture-drift`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-21T13:13:24Z`
- Subject: `repo:architecture-drift`
- Project root: `.`
- JSON path: `outputs/reports/repo_architecture_drift.json`
- Markdown path: `outputs/reports/repo_architecture_drift.md`

## Message

Architecture/code drift analysis completed in read-only mode.

## Summary

- `architecture_docs_existing`: 3
- `architecture_docs_total`: 3
- `code_modules_total`: 70
- `components_documented_total`: 94
- `dependency_nodes_total`: 199
- `drift_counts`: {'code_missing': 42, 'doc_missing': 18, 'name_mismatch': 8, 'in_sync': 44}
- `drift_detected`: True
- `external_api_used`: False
- `matrix_rows_total`: 112
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `repo_health_score`: 70
- `severity_counts`: {'warning': 42, 'info': 70}

## Findings

- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: AgentRuntime documental.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Artifact.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Checklist Validator.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: DTOs ApplicationRequest/Response.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Eval Harness offline.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: EventLogger JSONL.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Filesystem/docs.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Frontmatter Validator.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Git local.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: GitAdapter + RepoInventory.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: LocalStore SQLite v0.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: MIASI Registry Validator.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Model provider layer.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: ModelAdapter Router.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Policy Engine + Guards.
- **WARNING** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Readiness Gate.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/auditpack`: Code module has no evident architectural reference: auditpack.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/changes`: Code module has no evident architectural reference: changes.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/compliance`: Code module has no evident architectural reference: compliance.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/connectors`: Code module has no evident architectural reference: connectors.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/errors.py`: Code module has no evident architectural reference: errors.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/execution`: Code module has no evident architectural reference: execution.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/industrial`: Code module has no evident architectural reference: industrial.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/interfaces`: Code module has no evident architectural reference: interfaces.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/plugins`: Code module has no evident architectural reference: plugins.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/portfolio`: Code module has no evident architectural reference: portfolio.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/prompts`: Code module has no evident architectural reference: prompts.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/quality`: Code module has no evident architectural reference: quality.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/release`: Code module has no evident architectural reference: release.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/remote`: Code module has no evident architectural reference: remote.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/sandbox`: Code module has no evident architectural reference: sandbox.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/schemas`: Code module has no evident architectural reference: schemas.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/security`: Code module has no evident architectural reference: security.
- **WARNING** `ARCH_DRIFT_DOC_MISSING` — `src/devpilot_core/traceability`: Code module has no evident architectural reference: traceability.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/enterprise`: Documented component and code module only match heuristically: Enterprise Reporter -> enterprise.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/identity`: Documented component and code module only match heuristically: Identity/RBAC -> identity.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/identity`: Documented component and code module only match heuristically: Identity/RBAC Local -> identity.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/multiagent`: Documented component and code module only match heuristically: MultiAgent Orchestrator -> multiagent.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/review`: Documented component and code module only match heuristically: Patch/Code Review dry-run -> review.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/rag`: Documented component and code module only match heuristically: RAG Local Engine -> rag.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/store`: Documented component and code module only match heuristically: SQLite LocalStore -> store.
- **WARNING** `ARCH_DRIFT_NAME_MISMATCH` — `src/devpilot_core/refactor`: Documented component and code module only match heuristically: Safe Refactor Planner -> refactor.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: API local segura.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: AdvancedEvalHarness.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Agent Session Store.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: AgentSession.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Connector/MCP Layer.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: ConnectorAdapter.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: ConnectorRegistry.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Desktop UI.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: External APIs.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: External LLM APIs.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Handoff.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: MCP/API tools.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: MultiAgentCoordinator.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Multiworkspace.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Ollama/LM Studio clients.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Patch apply sandbox.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Plugin Registry.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: PluginRegistry.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Refactor execution.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Remote Runner Stub.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Remote runner stub\nexperimental/.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: RemoteRunner.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Web UI local.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_container.md`: Documented component has no evident source module: Web UI real.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: Web UI/API.
- **INFO** `ARCH_DRIFT_CODE_MISSING` — `docs/02_architecture/c4_component.md`: Documented component has no evident source module: WorkflowRunner.

## Report Metadata

- `component`: ArchitectureDriftDetector
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-38
