# DevPilot Evidence Report — agent_session_inspect_agsess_0ece4ed6972946919cf945dadb466fb6

## Metadata

- Report ID: `agent_session_inspect_agsess_0ece4ed6972946919cf945dadb466fb6`
- Command: `agent session inspect`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T02:36:04Z`
- Subject: `agsess_0ece4ed6972946919cf945dadb466fb6`
- Project root: `.`
- JSON path: `outputs/reports/agent_session_inspect_agsess_0ece4ed6972946919cf945dadb466fb6.json`
- Markdown path: `outputs/reports/agent_session_inspect_agsess_0ece4ed6972946919cf945dadb466fb6.md`

## Message

Agent session inspection passed.

## Summary

- `agents_total`: 1
- `events_returned`: 2
- `events_total`: 2
- `local_only`: True
- `localstore_projection_used`: True
- `memory_items_total`: 2
- `rag_enabled`: False
- `raw_outputs_stored`: False
- `raw_prompts_stored`: False
- `redaction_applied`: True
- `semantic_memory_enabled`: False
- `session_found`: True
- `storage_path`: .devpilot/agent_sessions/agsess_0ece4ed6972946919cf945dadb466fb6.json
- `tracestore_compatible`: True

## Findings

No findings.

## Report Metadata

- `component`: AgentSession
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-86
