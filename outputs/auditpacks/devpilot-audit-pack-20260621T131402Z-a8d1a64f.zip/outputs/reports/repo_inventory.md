# DevPilot Evidence Report — repo_inventory

## Metadata

- Report ID: `repo_inventory`
- Command: `repo-inventory`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-08T15:38:05Z`
- Subject: `.`
- Project root: `.`
- JSON path: `outputs/reports/repo_inventory.json`
- Markdown path: `outputs/reports/repo_inventory.md`

## Message

Repository inventory generated in read-only mode.

## Summary

- `by_category`: {'state': 1, 'configuration': 75, 'documentation': 265, 'other': 4, 'python': 57}
- `by_risk`: {'low': 345, 'medium': 1, 'high': 56}
- `files_total`: 402
- `secret_like_files`: 56
- `size_bytes_total`: 4120625
- `skipped_dirs`: ['.git', '.pytest_cache', '.venv', 'outputs', 'src/devpilot_core/__pycache__', 'src/devpilot_core/agents/__pycache__', 'src/devpilot_core/evals/__pycache__', 'src/devpilot_core/miasi/__pycache__', 'src/devpilot_core/observability/__pycache__', 'src/devpilot_core/policy/__pycache__', 'src/devpilot_core/repo/__pycache__', 'src/devpilot_core/reports/__pycache__', 'src/devpilot_core/standards/__pycache__', 'src/devpilot_core/store/__pycache__', 'src/devpilot_core/validators/__pycache__', 'src/devpilot_core/workspace/__pycache__', 'tests/__pycache__']

## Findings

- **WARNING** `REPO_INVENTORY_MEDIUM_RISK_FILE` — `.devpilot/devpilot.db`: Medium-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/03_security/privacy_assessment.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/03_security/privacy_assessment.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/03_security/security_threat_model.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/03_security/security_threat_model.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/05_operations/runbook.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/05_operations/runbook.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/audits/func_sprint_09_policy_engine_audit.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/audits/func_sprint_09_policy_engine_audit.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/functional_backlog_after_precode.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/functional_backlog_after_precode.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/functional_sprint_09_manifest.json`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/functional_sprint_09_manifest.json`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/00_manifesto.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/00_manifesto.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/01_modelo_ingenieria_sistemas_agenticos.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/01_modelo_ingenieria_sistemas_agenticos.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/02_arquitectura_referencia.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/02_arquitectura_referencia.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/03_agentic_sdlc.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/03_agentic_sdlc.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/04_estandares_tecnicos_transversales.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/04_estandares_tecnicos_transversales.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/05_plantillas_checklists_controles.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/05_plantillas_checklists_controles.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/07_auditoria_miasi.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/07_auditoria_miasi.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/adrs/ADR-0001-docs-as-code.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/adrs/ADR-0001-docs-as-code.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/adrs/ADR-0002-markdown-como-formato-base.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/adrs/ADR-0002-markdown-como-formato-base.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/adrs/ADR-0003-uso-de-c4-y-mermaid.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/adrs/ADR-0003-uso-de-c4-y-mermaid.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/adrs/ADR-0004-uso-de-diataxis.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/adrs/ADR-0004-uso-de-diataxis.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/adrs/ADR-0005-adaptacion-de-arc42.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/adrs/ADR-0005-adaptacion-de-arc42.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_agent_design.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_agent_design.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_ci_cd.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_ci_cd.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_eval_readiness.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_eval_readiness.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_human_approval.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_human_approval.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_memory_safety.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_memory_safety.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_observability_readiness.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_observability_readiness.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_post_deployment.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_post_deployment.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_pre_production.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_pre_production.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_rag_grounding.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_rag_grounding.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_security_readiness.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_security_readiness.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/checklists/checklist_tool_safety.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/checklists/checklist_tool_safety.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/doc_ai_002_manifest.json`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/doc_ai_002_manifest.json`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/doc_ai_006_manifest.json`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/doc_ai_006_manifest.json`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/README.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/README.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/adr_template.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/adr_template.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/agent_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/agent_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/cost_budget.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/cost_budget.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/data_handling_sheet.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/data_handling_sheet.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/deployment_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/deployment_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/eval_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/eval_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/human_approval_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/human_approval_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/incident_report.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/incident_report.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/memory_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/memory_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/model_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/model_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/observability_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/observability_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/policy_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/policy_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/production_readiness_checklist.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/production_readiness_checklist.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/rag_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/rag_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/risk_register.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/risk_register.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/runbook_template.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/runbook_template.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/threat_model.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/threat_model.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `docs/standards/miasi/templates/tool_card.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `docs/standards/miasi/templates/tool_card.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `evals/fixtures/documentation_eval_cases.json`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `evals/fixtures/documentation_eval_cases.json`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `README.md`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `README.md`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `tests/test_agent_runtime.py`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `tests/test_agent_runtime.py`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `tests/test_event_logger.py`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `tests/test_event_logger.py`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `tests/test_policy_engine.py`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `tests/test_policy_engine.py`: Secret-like content detected and not emitted in inventory output.
- **WARNING** `REPO_INVENTORY_HIGH_RISK_FILE` — `tests/test_repo_tools.py`: High-risk file pattern detected.
- **WARNING** `REPO_INVENTORY_SECRET_LIKE_CONTENT` — `tests/test_repo_tools.py`: Secret-like content detected and not emitted in inventory output.

## Report Metadata

- `component`: RepoInventory
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-14
