# DevPilot Evidence Report — metrics_summary

## Metadata

- Report ID: `metrics_summary`
- Command: `metrics summary`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-14T09:14:12Z`
- Subject: `observability:metrics`
- Project root: `.`
- JSON path: `outputs/reports/metrics_summary.json`
- Markdown path: `outputs/reports/metrics_summary.md`

## Message

Local metrics summary generated.

## Summary

- `categories`: {'agent': 19, 'command': 246, 'model': 273, 'policy': 235, 'tool': 51}
- `estimated_cost_total_usd`: 0.0
- `filter_category`: None
- `initialized`: True
- `limit`: 50
- `metrics_total`: 824
- `operations_total`: 642
- `providers`: {'mock': 273}
- `recent_categories`: {'agent': 2, 'command': 15, 'model': 15, 'policy': 13, 'tool': 5}
- `recent_metrics_total`: 50
- `recent_operations`: {'call_total': 5, 'calls_total': 5, 'check_total': 13, 'completed_total': 15, 'cost_estimate_usd': 5, 'run_total': 2, 'tokens_estimated': 5}
- `recent_providers`: {'mock': 15}
- `recent_statuses`: {'PASS': 40}
- `statuses`: {'BLOCK': 14, 'FAIL': 4, 'PASS': 624}
- `tokens_estimated_total`: 7909

## Findings

No findings.

## Report Metadata

- `component`: TraceQueryService
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-61
