# DevPilot Evidence Report — release_verification

## Metadata

- Report ID: `release_verification`
- Command: `release verify`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-20T16:22:47Z`
- Subject: `release:0.1.0:verify`
- Project root: `.`
- JSON path: `outputs/reports/release_verification.json`
- Markdown path: `outputs/reports/release_verification.md`

## Message

Release verification passed.

## Summary

- `artifact`: dist/release/test-devpilot-release.zip
- `artifact_exists`: True
- `checksum_passed`: True
- `deploy_performed`: False
- `exit_codes_observed`: True
- `external_api_used`: False
- `git_tagging_performed`: False
- `network_used`: False
- `preliminary`: True
- `publish_performed`: False
- `release_verified`: True
- `reports_written`: False
- `schema_version`: 1.0.0
- `sha256`: b1d188d79560e26660d9e4363d0c2523a4dfe75829f8af1e9076c862971df82d
- `sha256_generated`: True
- `smoke_test_passed`: True
- `source_mutations_performed`: False
- `subchecks_failed`: 0
- `subchecks_passed`: 2
- `subchecks_total`: 2
- `version`: 0.1.0

## Findings

- **INFO** `RELEASE_VERIFICATION_PASS`: Release verification passed for the local artifact.

## Report Metadata

- `component`: ReleaseVerification
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-81
- `version`: 0.1.0
