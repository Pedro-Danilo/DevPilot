# DevPilot Evidence Report — agent_session_inspect_agsess_52ffee694ae24bc993c0c84b614e3dd3

## Metadata

- Report ID: `agent_session_inspect_agsess_52ffee694ae24bc993c0c84b614e3dd3`
- Command: `agent session inspect`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T12:28:32Z`
- Subject: `agsess_52ffee694ae24bc993c0c84b614e3dd3`
- Project root: `.`
- JSON path: `outputs/reports/agent_session_inspect_agsess_52ffee694ae24bc993c0c84b614e3dd3.json`
- Markdown path: `outputs/reports/agent_session_inspect_agsess_52ffee694ae24bc993c0c84b614e3dd3.md`

## Message

Agent session inspection passed.

## Summary

- `agents_total`: 1
- `events_returned`: 2
- `events_total`: 2
- `local_only`: True
- `localstore_projection_used`: True
- `memory_items_total`: 2
- `rag_enabled`: False
- `raw_outputs_stored`: False
- `raw_prompts_stored`: False
- `redaction_applied`: True
- `semantic_memory_enabled`: False
- `session_found`: True
- `storage_path`: .devpilot/agent_sessions/agsess_52ffee694ae24bc993c0c84b614e3dd3.json
- `tracestore_compatible`: True

## Findings

No findings.

## Report Metadata

- `component`: AgentSession
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-86
