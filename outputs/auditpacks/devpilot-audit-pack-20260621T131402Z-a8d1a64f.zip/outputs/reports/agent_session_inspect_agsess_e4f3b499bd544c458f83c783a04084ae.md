# DevPilot Evidence Report — agent_session_inspect_agsess_e4f3b499bd544c458f83c783a04084ae

## Metadata

- Report ID: `agent_session_inspect_agsess_e4f3b499bd544c458f83c783a04084ae`
- Command: `agent session inspect`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-18T14:58:04Z`
- Subject: `agsess_e4f3b499bd544c458f83c783a04084ae`
- Project root: `.`
- JSON path: `outputs/reports/agent_session_inspect_agsess_e4f3b499bd544c458f83c783a04084ae.json`
- Markdown path: `outputs/reports/agent_session_inspect_agsess_e4f3b499bd544c458f83c783a04084ae.md`

## Message

Agent session inspection passed.

## Summary

- `agents_total`: 1
- `events_returned`: 2
- `events_total`: 2
- `local_only`: True
- `localstore_projection_used`: True
- `memory_items_total`: 2
- `rag_enabled`: False
- `raw_outputs_stored`: False
- `raw_prompts_stored`: False
- `redaction_applied`: True
- `semantic_memory_enabled`: False
- `session_found`: True
- `storage_path`: .devpilot/agent_sessions/agsess_e4f3b499bd544c458f83c783a04084ae.json
- `tracestore_compatible`: True

## Findings

No findings.

## Report Metadata

- `component`: AgentSession
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-86
