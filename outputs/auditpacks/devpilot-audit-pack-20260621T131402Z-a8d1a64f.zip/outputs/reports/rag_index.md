# DevPilot Evidence Report — rag_index

## Metadata

- Report ID: `rag_index`
- Command: `rag index`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-18T16:00:32Z`
- Subject: `docs`
- Project root: `.`
- JSON path: `outputs/reports/rag_index.json`
- Markdown path: `outputs/reports/rag_index.md`

## Message

Local lexical RAG index created.

## Summary

- `chunk_lines`: 40
- `chunks_total`: 2615
- `embeddings_enabled`: False
- `external_api_used`: False
- `files_indexed_total`: 556
- `files_skipped_total`: 0
- `index_path`: D:/Projects/DevPilot_Local/.devpilot/rag/docs_index.json
- `lexical_index`: True
- `llm_used`: False
- `local_only`: True
- `mutations_performed`: True
- `network_used`: False
- `overlap_lines`: 5
- `path_guard_used`: True
- `preliminary`: True
- `redactions_total`: 82
- `reports_written`: False
- `runtime_state_mutated`: True
- `schema_version`: 1.0.0
- `secret_guard_used`: True
- `target`: D:/Projects/DevPilot_Local/docs
- `target_allowed`: True

## Findings

- **INFO** `RAG_INDEX_CREATED`: Local lexical RAG index was created with source metadata and SecretGuard redaction.
- **WARNING** `RAG_INDEX_REDACTIONS_APPLIED`: SecretGuard redacted content before indexing.

## Report Metadata

- `component`: LocalRagIndexer
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-87
- `target`: docs
