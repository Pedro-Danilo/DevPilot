# DevPilot Evidence Report — rag_query

## Metadata

- Report ID: `rag_query`
- Command: `rag query`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-18T16:00:46Z`
- Subject: `Qué valida readiness strict`
- Project root: `.`
- JSON path: `outputs/reports/rag_query.json`
- Markdown path: `outputs/reports/rag_query.md`

## Message

RAG query completed with grounded local sources.

## Summary

- `answer_generated`: True
- `chunks_available_total`: 2615
- `embeddings_enabled`: False
- `external_api_used`: False
- `grounded`: True
- `index_loaded`: True
- `index_path`: D:/Projects/DevPilot_Local/.devpilot/rag/docs_index.json
- `lexical_retrieval`: True
- `llm_used`: False
- `network_used`: False
- `path_guard_used`: True
- `preliminary`: True
- `redactions_total`: 0
- `schema_version`: 1.0.0
- `secret_guard_used`: True
- `sources_total`: 5
- `top_k`: 5

## Findings

- **INFO** `RAG_QUERY_GROUNDED_SOURCES`: RAG query returned a grounded answer with local source references.

## Report Metadata

- `component`: LocalRagRetriever
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-87
