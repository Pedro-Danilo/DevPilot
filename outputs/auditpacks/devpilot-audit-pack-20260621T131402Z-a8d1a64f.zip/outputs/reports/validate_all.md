# DevPilot Evidence Report — validate_all

## Metadata

- Report ID: `validate_all`
- Command: `validate all`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-20T16:36:42Z`
- Subject: `validation:all`
- Project root: `.`
- JSON path: `outputs/reports/validate_all.json`
- Markdown path: `outputs/reports/validate_all.md`

## Message

Validation gateway passed all configured groups.

## Summary

- `blocking_findings_total`: 0
- `external_api_used`: False
- `findings_total`: 112
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `scope`: all
- `validations_failed`: 0
- `validations_passed`: 2
- `validations_total`: 2
- `warnings_total`: 12

## Findings

- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `ARTIFACT_PROFILE_REGISTRY_PASS`: Artifact profile registry passed compatibility validation.
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/01_requirements/use_cases.md`: Recommended section is missing for profile 'use-cases': criterios
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/02_architecture/c4_context.md`: Recommended section is missing for profile 'c4-context': mermaid
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/02_architecture/c4_container.md`: Recommended section is missing for profile 'c4-container': mermaid
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/03_security/security_threat_model.md`: Recommended section is missing for profile 'security-threat-model': miasi
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/04_quality/test_strategy.md`: Recommended section is missing for profile 'test-strategy': coverage
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/06_miasi/agent_card.md`: Recommended section is missing for profile 'miasi-agent-card': herramientas
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/06_miasi/tool_card.md`: Recommended section is missing for profile 'miasi-tool-card': aprobación
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/checklists/checklist_pre_code.md`: Recommended section is missing for profile 'generic-markdown': estado
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_audit_report.md`: Recommended section is missing for profile 'generic-markdown': propósito
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_audit_report.md`: Recommended section is missing for profile 'generic-markdown': estado
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_baseline_decision.md`: Recommended section is missing for profile 'generic-markdown': propósito
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_baseline_decision.md`: Recommended section is missing for profile 'generic-markdown': estado
- **INFO** `SCHEMA_REGISTRY_PASS`: Schema registry catalog integrity passed.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.
- **INFO** `SCHEMA_VALIDATION_PASS`: Instance conforms to schema.

## Report Metadata

- `component`: ValidationGateway
- `contract`: EvidenceReport
- `scope`: all
- `sprint`: FUNC-SPRINT-24
