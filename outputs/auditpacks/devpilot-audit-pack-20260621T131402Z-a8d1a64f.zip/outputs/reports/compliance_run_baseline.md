# DevPilot Evidence Report — compliance_run_baseline

## Metadata

- Report ID: `compliance_run_baseline`
- Command: `compliance run`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-20T15:14:41Z`
- Subject: `compliance:baseline`
- Project root: `.`
- JSON path: `outputs/reports/compliance_run_baseline.json`
- Markdown path: `outputs/reports/compliance_run_baseline.md`

## Message

Compliance pack passed.

## Summary

- `blocking_findings_total`: 0
- `checks_failed`: 0
- `checks_passed`: 5
- `checks_total`: 5
- `declared_checks_only`: True
- `external_api_used`: False
- `gaps_total`: 0
- `mutations_performed`: False
- `network_used`: False
- `pack_id`: baseline
- `pack_title`: MIPSoftware/MIASI baseline compliance pack
- `packs_are_declarative`: True
- `policy_engine_replaced`: False
- `policy_engine_used`: True
- `preliminary`: True
- `profile`: mipsoftware-miasi-baseline
- `registry_valid`: True
- `source_mutations_performed`: False

## Findings

- **INFO** `COMPLIANCE_PACK_PASS`: Compliance pack passed using existing declared DevPilot gates.

## Report Metadata

- `component`: CompliancePackRunner
- `contract`: EvidenceReport
- `pack`: baseline
- `sprint`: FUNC-SPRINT-97
