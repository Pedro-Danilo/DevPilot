# DevPilot Evidence Report — telemetry_export_otel_dry_run

## Metadata

- Report ID: `telemetry_export_otel_dry_run`
- Command: `telemetry export`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-14T12:07:41Z`
- Subject: `observability:otel-dry-run`
- Project root: `.`
- JSON path: `outputs/reports/telemetry_export_otel_dry_run.json`
- Markdown path: `outputs/reports/telemetry_export_otel_dry_run.md`

## Message

OpenTelemetry dry-run payload generated locally.

## Summary

- `collector_required`: False
- `dry_run`: True
- `endpoint_configured`: False
- `events_exported`: 20
- `external_api_used`: False
- `format`: otlp
- `metrics_exported`: 100
- `network_used`: False
- `payload_redacted`: True
- `preliminary`: True
- `remote_telemetry_enabled`: False
- `resource_metrics_total`: 1
- `resource_spans_total`: 1
- `spans_exported`: 20
- `trace_id`: None

## Findings

No findings.

## Report Metadata

- `component`: OTelDryRunExporter
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-62
