# DevPilot Evidence Report — history_list

## Metadata

- Report ID: `history_list`
- Command: `history list`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-08T12:40:13Z`
- Subject: `.devpilot/devpilot.db`
- Project root: `.`
- JSON path: `outputs/reports/history_list.json`
- Markdown path: `outputs/reports/history_list.md`

## Message

Local history listed.

## Summary

- `limit`: 10
- `runs_returned`: 10

## Findings

No findings.

## Report Metadata

- `component`: LocalStore
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-10
