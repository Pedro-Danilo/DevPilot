# DevPilot Evidence Report — approval_request

## Metadata

- Report ID: `approval_request`
- Command: `approval request`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-11T09:39:26Z`
- Subject: `APPROVAL-CED9529EEF49`
- Project root: `.`
- JSON path: `outputs/reports/approval_request.json`
- Markdown path: `outputs/reports/approval_request.md`

## Message

Approval request persisted.

## Summary

- `approvals_total`: 1
- `created`: True
- `event_type`: approval.requested
- `preliminary`: True
- `status`: requested

## Findings

- **INFO** `APPROVAL_REQUEST_PERSISTED`: Approval record persisted with scope and expiration.

## Report Metadata

- `component`: ApprovalService
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-29
