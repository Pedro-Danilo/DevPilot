# DevPilot Evidence Report — trace_report

## Metadata

- Report ID: `trace_report`
- Command: `trace report`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-14T09:14:03Z`
- Subject: `observability:traces`
- Project root: `.`
- JSON path: `outputs/reports/trace_report.json`
- Markdown path: `outputs/reports/trace_report.md`

## Message

Local trace report generated.

## Summary

- `events_scanned`: 100
- `include_events`: True
- `include_metrics`: True
- `limit`: 20
- `metrics_scanned`: 500
- `span_types`: {'agent.run': 4, 'model.call': 6, 'policy.check': 23, 'tool.call': 10}
- `spans_scanned`: 100
- `statuses`: {'ok': 42, 'block': 1}
- `traces_total`: 20

## Findings

No findings.

## Report Metadata

- `component`: TraceQueryService
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-61
