# DevPilot Evidence Report — backup_restore

## Metadata

- Report ID: `backup_restore`
- Command: `backup restore`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-17T23:07:23Z`
- Subject: `backup:restore:backup-20260617T230617Z-78ac8d90`
- Project root: `.`
- JSON path: `outputs/reports/backup_restore.json`
- Markdown path: `outputs/reports/backup_restore.md`

## Message

Backup restore plan generated.

## Summary

- `backup_id`: backup-20260617T230617Z-78ac8d90
- `blocked_entries_total`: 0
- `confirm_restore`: False
- `deploys_artifacts`: False
- `dry_run`: True
- `execute_requested`: False
- `external_api_used`: False
- `git_tagging_performed`: False
- `network_used`: False
- `preliminary`: True
- `publishes_artifacts`: False
- `restore_entries_total`: 10
- `restore_overwrites_require_confirmation`: True
- `restore_performed`: False
- `restored_files_total`: 0
- `source_backup_zip`: .devpilot/backups/backup-20260617T230617Z-78ac8d90.zip
- `source_manifest`: .devpilot/backups/backup-20260617T230617Z-78ac8d90.manifest.json

## Findings

- **INFO** `BACKUP_RESTORE_DRY_RUN`: Backup restore ran in dry-run mode; no files were overwritten.

## Report Metadata

- `backup_id`: backup-20260617T230617Z-78ac8d90
- `component`: BackupRestore
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-83
