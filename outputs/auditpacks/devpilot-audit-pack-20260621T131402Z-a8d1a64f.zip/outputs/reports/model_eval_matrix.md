# DevPilot Evidence Report — model_eval_matrix

## Metadata

- Report ID: `model_eval_matrix`
- Command: `model eval run`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-20T15:17:34Z`
- Subject: `evals/model_fixtures/model_eval_cases.json`
- Project root: `.`
- JSON path: `outputs/reports/model_eval_matrix.json`
- Markdown path: `outputs/reports/model_eval_matrix.md`

## Message

Model evaluation matrix passed.

## Summary

- `cases_total`: 3
- `cost_estimate_total_usd`: 0.0
- `external_api_used`: False
- `failed_total`: 0
- `latency_ms_total`: 400.101
- `model`: None
- `network_used`: False
- `passed_total`: 3
- `preliminary`: True
- `provider`: mock
- `raw_outputs_stored`: False
- `raw_prompts_stored`: False
- `skipped_total`: 0
- `suite`: model-local-smoke
- `tokens_estimated_total`: 114

## Findings

- **INFO** `MODEL_EVAL_MATRIX_PASS`: Model evaluation matrix completed without failed cases.

## Report Metadata

- `component`: ModelEvalRunner
- `sprint`: FUNC-SPRINT-50
