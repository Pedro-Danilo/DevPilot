# DevPilot Evidence Report — agentops_status

## Metadata

- Report ID: `agentops_status`
- Command: `agentops status`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-14T13:02:28Z`
- Subject: `observability:agentops-quality-gate`
- Project root: `.`
- JSON path: `outputs/reports/agentops_status.json`
- Markdown path: `outputs/reports/agentops_status.md`

## Message

AgentOps quality gate passed.

## Summary

- `blocking_findings_total`: 0
- `events_scanned`: 100
- `external_api_used`: False
- `metrics_scanned`: 200
- `metrics_total`: 1263
- `network_used`: False
- `next_phase`: FASE-F-PRODUCTO-VISUAL
- `next_sprint`: FUNC-SPRINT-64
- `operational_status`: PASS
- `phase`: FASE-E-AGENTOPS-OBSERVABILIDAD
- `phase_e_closure_ready`: True
- `preliminary`: True
- `remote_telemetry_enabled`: False
- `spans_scanned`: 100
- `store_initialized`: True
- `traces_observed_total`: 67
- `ui_required`: False
- `warnings_total`: 0

## Findings

No findings.

## Report Metadata

- `component`: AgentOpsQualityGate
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-63
