# DevPilot Evidence Report — policy_check

## Metadata

- Report ID: `policy_check`
- Command: `policy check`
- Status: `BLOCK`
- OK: `false`
- Exit code: `2`
- Generated at: `2026-06-08T12:11:16Z`
- Subject: `docs/file.md`
- Project root: `.`
- JSON path: `outputs/reports/policy_check.json`
- Markdown path: `outputs/reports/policy_check.md`

## Message

Policy check blocked or denied the simulated request.

## Summary

- `allowed`: False
- `blocked`: True
- `decisions_total`: 3
- `denied`: False
- `guards`: ['CostGuard', 'PathGuard', 'SecretGuard']
- `warnings`: 0

## Findings

- **BLOCK** `SECRETGUARD_SECRET_DETECTED` — `docs/file.md`: SecretGuard detected and redacted secret-like content.

## Report Metadata

- `component`: PolicyEngine
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-09
