# DevPilot Evidence Report — git_status

## Metadata

- Report ID: `git_status`
- Command: `git-status`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-08T15:33:53Z`
- Subject: `.`
- Project root: `.`
- JSON path: `outputs/reports/git_status.json`
- Markdown path: `outputs/reports/git_status.md`

## Message

Git status collected in read-only mode.

## Summary

- `branch`: main
- `counts`: {'entries_total': 12, 'modified': 8, 'added': 0, 'deleted': 0, 'renamed': 0, 'untracked': 4, 'staged': 0}
- `diff_stat`: .devpilot/miasi/tool_registry.json                 |  6 +--
 README.md                                          | 45 ++++++++++++++--
 .../ADR-0005-git-adapter-read-only-mvp-plus.md     | 22 +++++++-
 docs/04_quality/test_strategy.md                   | 17 ++++++
 docs/05_operations/runbook.md                      | 62 +++++++++++++++++++++
 docs/06_miasi/tool_card.md                         | 26 +++++++++
 docs/functional_backlog_after_precode.md           | 51 ++++++++++++++----
 src/devpilot_core/cli.py                           | 63 ++++++++++++++++++++++
 8 files changed, 275 insertions(+), 17 deletions(-)
- `git_available`: True
- `git_root`: .
- `is_git_repo`: True
- `short_status`: [' M .devpilot/miasi/tool_registry.json', ' M README.md', ' M docs/02_architecture/adrs/ADR-0005-git-adapter-read-only-mvp-plus.md', ' M docs/04_quality/test_strategy.md', ' M docs/05_operations/runbook.md', ' M docs/06_miasi/tool_card.md', ' M docs/functional_backlog_after_precode.md', ' M src/devpilot_core/cli.py', '?? docs/audits/func_sprint_14_git_readonly_inventory_audit.md', '?? docs/functional_sprint_14_manifest.json', '?? src/devpilot_core/repo/', '?? tests/test_repo_tools.py']
- `staged_diff_stat`: 

## Findings

- **INFO** `GIT_STATUS_READ_ONLY_PASS`: Git status was collected using read-only commands.
- **WARNING** `GIT_UNTRACKED_FILES_PRESENT`: Untracked files are present.
- **WARNING** `GIT_WORKTREE_CHANGES_PRESENT`: Working tree changes are present.

## Report Metadata

- `component`: GitAdapter
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-14
