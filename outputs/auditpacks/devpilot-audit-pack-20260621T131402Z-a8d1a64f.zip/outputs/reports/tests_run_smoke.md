# DevPilot Evidence Report — tests_run_smoke

## Metadata

- Report ID: `tests_run_smoke`
- Command: `tests run`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-11T13:33:54Z`
- Subject: `tests.run:smoke`
- Project root: `.`
- JSON path: `outputs/reports/tests_run_smoke.json`
- Markdown path: `outputs/reports/tests_run_smoke.md`

## Message

tests.run completed successfully.

## Summary

- `allowed_by_policy`: True
- `approval_id`: APPROVAL-8F0C4C5F4BC7
- `executed`: True
- `preliminary`: True
- `profile`: smoke
- `redactions`: 0
- `returncode`: 0
- `timed_out`: False
- `timeout_seconds`: 60

## Findings

- **INFO** `TESTS_RUN_PASS`: tests.run executed an approved allowlisted pytest profile successfully.

## Report Metadata

- `component`: TestsRunTool
- `contract`: EvidenceReport
- `profile`: smoke
- `sprint`: FUNC-SPRINT-32
