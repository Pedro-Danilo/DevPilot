# DevPilot Evidence Report — schema_list

## Metadata

- Report ID: `schema_list`
- Command: `schema list`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-20T16:36:20Z`
- Subject: `docs/schemas/schema_catalog.json`
- Project root: `.`
- JSON path: `outputs/reports/schema_list.json`
- Markdown path: `outputs/reports/schema_list.md`

## Message

Schema registry listed successfully.

## Summary

- `catalog_path`: docs/schemas/schema_catalog.json
- `duplicate_schema_ids`: []
- `missing_schema_paths`: []
- `preliminary`: True
- `schemas_existing`: 27
- `schemas_total`: 27

## Findings

- **INFO** `SCHEMA_REGISTRY_PASS`: Schema registry catalog integrity passed.

## Report Metadata

- `component`: SchemaRegistry
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-21
