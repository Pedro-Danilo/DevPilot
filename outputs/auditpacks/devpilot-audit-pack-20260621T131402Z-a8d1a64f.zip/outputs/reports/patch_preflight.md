# DevPilot Evidence Report — patch_preflight

## Metadata

- Report ID: `patch_preflight`
- Command: `patch check`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-12T12:12:52Z`
- Subject: `safe.patch`
- Project root: `.`
- JSON path: `outputs/reports/patch_preflight.json`
- Markdown path: `outputs/reports/patch_preflight.md`

## Message

Patch preflight passed in dry-run mode.

## Summary

- `applicability_fail`: False
- `applies`: True
- `apply_check_executed`: True
- `apply_check_exit_code`: 0
- `blocking_findings`: 0
- `dry_run`: True
- `external_api_used`: False
- `failing_findings`: 0
- `findings_total`: 1
- `mutations_performed`: False
- `network_used`: False
- `patch_applied`: False
- `patch_review_exit_code`: 0
- `patch_review_ok`: True
- `preliminary`: True
- `review_blocking_findings`: 0
- `review_failing_findings`: 0
- `security_block`: False
- `source`: safe.patch
- `warnings_total`: 0
- `working_tree_unchanged`: True

## Findings

- **INFO** `PATCH_PREFLIGHT_APPLY_CHECK_PASS` — `safe.patch`: git apply --check reported that the patch is applicable without applying it.

## Report Metadata

- `component`: PatchPreflightEngine
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-40
