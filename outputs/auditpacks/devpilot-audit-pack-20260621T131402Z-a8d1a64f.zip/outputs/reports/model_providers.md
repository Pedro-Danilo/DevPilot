# DevPilot Evidence Report — model_providers

## Metadata

- Report ID: `model_providers`
- Command: `model providers`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-08T19:11:53Z`
- Subject: `.devpilot/providers.yaml.example`
- Project root: `.`
- JSON path: `outputs/reports/model_providers.json`
- Markdown path: `outputs/reports/model_providers.md`

## Message

Model provider registry status passed.

## Summary

- `api_providers_total`: 2
- `enabled_total`: 1
- `local_providers_total`: 2
- `mock_providers_total`: 1
- `providers_total`: 5
- `source_path`: .devpilot/providers.yaml.example
- `used_example`: True

## Findings

- **INFO** `MODEL_PROVIDER_REGISTRY_PASS`: Model provider registry loaded without raw secret values.

## Report Metadata

- `component`: ProviderRegistry
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-17
