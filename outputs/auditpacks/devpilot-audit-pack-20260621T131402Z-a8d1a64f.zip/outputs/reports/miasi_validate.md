# DevPilot Evidence Report — miasi_validate

## Metadata

- Report ID: `miasi_validate`
- Command: `miasi validate`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-08T13:02:31Z`
- Subject: `.devpilot/miasi`
- Project root: `.`
- JSON path: `outputs/reports/miasi_validate.json`
- Markdown path: `outputs/reports/miasi_validate.md`

## Message

MIASI executable registry validation passed.

## Summary

- `agents_total`: 13
- `approval_gated_rules`: 6
- `high_risk_tools`: 4
- `mvp_agents`: 2
- `policy_rules_total`: 14
- `source_paths`: {'agent_registry': '.devpilot/miasi/agent_registry.json', 'tool_registry': '.devpilot/miasi/tool_registry.json', 'policy_matrix': '.devpilot/miasi/policy_matrix.json'}
- `tools_total`: 20

## Findings

- **INFO** `MIASI_POLICY_MATRIX_PASS`: Policy Matrix coverage passed.
- **INFO** `MIASI_TOOL_REGISTRY_PASS`: Tool Registry validation passed.
- **INFO** `MIASI_AGENT_REGISTRY_PASS`: Agent Registry validation passed.

## Report Metadata

- `component`: MiasiRegistryValidator
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-11
