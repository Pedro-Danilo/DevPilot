# DevPilot Evidence Report — tests_run_unit

## Metadata

- Report ID: `tests_run_unit`
- Command: `tests run`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-11T15:19:40Z`
- Subject: `tests.run:unit`
- Project root: `.`
- JSON path: `outputs/reports/tests_run_unit.json`
- Markdown path: `outputs/reports/tests_run_unit.md`

## Message

tests.run completed successfully.

## Summary

- `allowed_by_policy`: True
- `approval_id`: APPROVAL-CB0878C8790B
- `executed`: True
- `preliminary`: True
- `profile`: unit
- `redactions`: 0
- `returncode`: 0
- `timed_out`: False
- `timeout_seconds`: 120

## Findings

- **INFO** `TESTS_RUN_PASS`: tests.run executed an approved allowlisted pytest profile successfully.

## Report Metadata

- `component`: TestsRunTool
- `contract`: EvidenceReport
- `profile`: unit
- `sprint`: FUNC-SPRINT-32
