# Redacted audit-pack artifact

Original path: docs/05_operations/runbook.md
Redactions: 9
Raw content was not exported because SecretGuard detected secret-like material.
