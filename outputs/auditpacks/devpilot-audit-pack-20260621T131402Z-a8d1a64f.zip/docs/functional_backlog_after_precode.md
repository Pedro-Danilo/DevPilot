# Redacted audit-pack artifact

Original path: docs/functional_backlog_after_precode.md
Redactions: 2
Raw content was not exported because SecretGuard detected secret-like material.
