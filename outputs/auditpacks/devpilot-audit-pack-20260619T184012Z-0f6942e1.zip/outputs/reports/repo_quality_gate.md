# DevPilot Evidence Report — repo_quality_gate

## Metadata

- Report ID: `repo_quality_gate`
- Command: `repo quality-gate`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T17:25:04Z`
- Subject: `.`
- Project root: `.`
- JSON path: `outputs/reports/repo_quality_gate.json`
- Markdown path: `outputs/reports/repo_quality_gate.md`

## Message

Repo quality gate passed in dry-run mode.

## Summary

- `blocking_findings`: 0
- `code_target`: src/devpilot_core/repo
- `components_total`: 5
- `dry_run`: True
- `external_api_used`: False
- `failing_findings`: 0
- `findings_total`: 11
- `mutations_performed`: False
- `network_used`: False
- `patch_applied`: False
- `patch_reviewed`: False
- `preliminary`: True
- `rule_hits_total`: 6
- `rule_packs_total`: 4
- `status`: PASS
- `target`: .
- `warnings_total`: 8

## Findings

- **INFO** `QUALITY_GATE_POLICY_POLICY_PASS`: PolicyEngine allowed the simulated request.
- **INFO** `QUALITY_GATE_POLICY_POLICY_PASS`: PolicyEngine allowed the simulated request.
- **WARNING** `QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_LARGE_FILES`: Large files were detected; review maintainability and report size impact.
- **WARNING** `QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_MODULES_WITHOUT_NEAR_TESTS`: Some modules do not have obvious nearby/direct tests by heuristic.
- **WARNING** `QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_GIT_WORKTREE_CHANGES`: Working tree changes are present during analysis.
- **WARNING** `QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_UPSTREAM_GIT_UNTRACKED_FILES_PRESENT`: Upstream git finding: Untracked files are present.
- **WARNING** `QUALITY_GATE_REPO_ANALYZER_REPO_ANALYZER_UPSTREAM_GIT_WORKTREE_CHANGES_PRESENT`: Upstream git finding: Working tree changes are present.
- **WARNING** `QUALITY_GATE_CODE_REVIEW_CODE_REVIEW_TODO` — `src/devpilot_core/repo/analyzer.py`: TODO/FIXME marker detected.
- **WARNING** `QUALITY_GATE_CODE_REVIEW_CODE_REVIEW_TODO` — `src/devpilot_core/repo/analyzer.py`: TODO/FIXME marker detected.
- **WARNING** `QUALITY_GATE_CODE_REVIEW_CODE_REVIEW_TODO` — `src/devpilot_core/repo/analyzer.py`: TODO/FIXME marker detected.
- **INFO** `QUALITY_GATE_PATCH_REVIEW_QUALITY_GATE_PATCH_REVIEW_SKIPPED`: Patch review skipped: no patch supplied.

## Report Metadata

- `component`: RepoQualityGate
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-39
