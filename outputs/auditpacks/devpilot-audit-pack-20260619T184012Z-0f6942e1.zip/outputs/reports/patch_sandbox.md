# DevPilot Evidence Report — patch_sandbox

## Metadata

- Report ID: `patch_sandbox`
- Command: `patch sandbox`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T17:07:28Z`
- Subject: `safe.patch`
- Project root: `.`
- JSON path: `outputs/reports/patch_sandbox.json`
- Markdown path: `outputs/reports/patch_sandbox.md`

## Message

Patch sandbox completed successfully.

## Summary

- `blocking_findings`: 0
- `changeset_files`: 1
- `changeset_id`: changeset-e27d8c58a288e042
- `cleanup_removed`: True
- `cleanup_requested`: True
- `effective_changes`: 1
- `external_api_used`: False
- `failing_findings`: 0
- `findings_total`: 2
- `mutations_scope`: outputs/sandbox only
- `network_used`: False
- `patch_applied_in_sandbox`: True
- `patch_applied_to_productive_workspace`: False
- `preflight_ok`: True
- `preliminary`: True
- `productive_workspace_unchanged`: True
- `run_tests_requested`: False
- `sandbox_created`: True
- `sandbox_id`: patch-sandbox-20260619T170725Z-3293b635
- `sandbox_workspace`: outputs/sandbox/patch-sandbox-20260619T170725Z-3293b635/workspace
- `source`: safe.patch
- `tests_executed`: False
- `tests_ok`: None

## Findings

- **INFO** `PATCH_SANDBOX_APPLY_PASS` — `safe.patch`: Patch was applied inside sandbox workspace only.
- **INFO** `PATCH_SANDBOX_PYTHON_FALLBACK_APPLIED` — `safe.patch`: Deterministic Python fallback applied text hunks after git apply produced no effective ChangeSet.

## Report Metadata

- `component`: PatchSandboxManager
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-41
