# DevPilot Evidence Report — release_changelog

## Metadata

- Report ID: `release_changelog`
- Command: `release changelog`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T17:10:17Z`
- Subject: `release:0.1.0:changelog`
- Project root: `.`
- JSON path: `outputs/reports/release_changelog.json`
- Markdown path: `outputs/reports/release_changelog.md`

## Message

Release changelog generated.

## Summary

- `categories`: ['Added', 'Changed', 'Deprecated', 'Removed', 'Fixed', 'Security']
- `categories_total`: 6
- `channel`: local-candidate
- `dry_run`: True
- `entries_total`: 73
- `external_api_used`: False
- `manifests_total`: 23
- `mutations_performed`: False
- `network_used`: False
- `preliminary`: True
- `release_id`: DEVPL-0.1.0
- `release_status`: candidate-local
- `reports_written`: False
- `schema_version`: 1.0.0
- `source_manifests_total`: 23
- `source_mutations_performed`: False
- `valid_version`: True
- `version`: 0.1.0

## Findings

- **INFO** `RELEASE_CHANGELOG_CREATED`: Release changelog was generated from local sprint manifests without network, publication or source mutation.

## Report Metadata

- `component`: ReleaseChangelog
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-78
- `version`: 0.1.0
