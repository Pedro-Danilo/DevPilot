# DevPilot Evidence Report — app_contract

## Metadata

- Report ID: `app_contract`
- Command: `app contract`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T18:36:46Z`
- Subject: `docs/07_interfaces/internal_application_contract.md`
- Project root: `.`
- JSON path: `outputs/reports/app_contract.json`
- Markdown path: `outputs/reports/app_contract.md`

## Message

Application service v2 contract is available for CLI, secured local API MVP, Web UI viewers, Approval Center, Settings UI and Fase F visual MVP closure; desktop is deferred.

## Summary

- `api_consumed_by_web_ui`: True
- `api_contract_defined`: True
- `api_contract_version`: v1
- `api_cors_restricted`: True
- `api_cors_wildcard_enabled`: False
- `api_default_host`: 127.0.0.1
- `api_default_port`: 8787
- `api_implemented`: True
- `api_local_mvp_implemented`: True
- `api_local_planned`: True
- `api_policy_binding_enabled`: True
- `api_security_implemented`: True
- `api_security_status`: secured-initial
- `api_service_mapping_path`: docs/07_interfaces/api_service_mapping.md
- `api_token_required`: True
- `application_service_v2`: True
- `approval_center_implemented`: True
- `approval_center_status`: implemented-initial
- `capabilities_total`: 38
- `contract`: DevPilotApplicationServiceContract
- `desktop_deferred`: True
- `desktop_ready_for_shell`: False
- `domain_facades_enabled`: True
- `domains_total`: 13
- `dry_run_action_launcher_implemented`: True
- `external_api_required`: False
- `next_phase`: FASE-G-PRODUCTIZACION-RELEASE
- `next_sprint`: FUNC-SPRINT-74
- `openapi_contract_defined`: True
- `openapi_contract_path`: docs/07_interfaces/openapi_v1.json
- `phase_f_closed`: True
- `phase_f_closure_report_path`: docs/audits/phase_f_visual_product_closure_report.md
- `preliminary`: True
- `report_trace_viewer_status`: implemented-initial
- `report_viewer_implemented`: True
- `routes_total`: 29
- `schema_version`: 2.0
- `settings_policy_editor_enabled`: False
- `settings_provider_editor_plan_only`: True
- `settings_secrets_redacted`: True
- `settings_ui_implemented`: True
- `settings_ui_read_only`: True
- `settings_ui_status`: implemented-initial
- `trace_viewer_implemented`: True
- `ui_implemented`: True
- `visual_product_mvp_release`: True
- `visual_product_quality_gate`: True
- `visual_product_quality_gate_path`: scripts/visual_product_smoke.py
- `visual_product_release_manifest_path`: docs/release/release_manifest_visual_mvp.json
- `visual_strategy`: web_ui_first
- `web_dashboard_ready`: True
- `web_ready_for_shell`: True
- `web_real_evolution_planned`: True
- `web_ui_actions_dry_run_only`: True
- `web_ui_api_only`: True
- `web_ui_critical_actions_blocked`: True
- `web_ui_local_implemented`: True
- `web_ui_local_planned`: True
- `web_ui_path`: ui/web
- `web_ui_read_only`: True
- `web_ui_real_future`: True
- `web_ui_reports_api_only`: True
- `web_ui_status`: implemented-initial
- `web_ui_traces_api_only`: True

## Findings

- **INFO** `APP_CONTRACT_V2_PASS`: ApplicationService v2 exposes domain facades plus secured local API route contracts, Web UI viewers, Approval Center, Settings UI and Fase F visual MVP closure.

## Report Metadata

- `component`: ApplicationService v2
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-65
