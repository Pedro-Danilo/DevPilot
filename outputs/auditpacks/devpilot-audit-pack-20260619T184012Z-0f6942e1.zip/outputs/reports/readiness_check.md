# DevPilot Evidence Report — readiness_check

## Metadata

- Report ID: `readiness_check`
- Command: `readiness-check`
- Status: `PASS`
- OK: `true`
- Exit code: `0`
- Generated at: `2026-06-19T17:07:29Z`
- Project root: `.`
- JSON path: `outputs/reports/readiness_check.json`
- Markdown path: `outputs/reports/readiness_check.md`

## Message

Strict pre-code readiness gate passed.

## Summary

- `artifact_validation_pass`: 25
- `findings_total`: 12
- `frontmatter_pass`: 25
- `required_artifacts_present`: 25
- `required_artifacts_total`: 25

## Findings

- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/01_requirements/use_cases.md`: Recommended section is missing for profile 'use-cases': criterios
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/02_architecture/c4_context.md`: Recommended section is missing for profile 'c4-context': mermaid
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/02_architecture/c4_container.md`: Recommended section is missing for profile 'c4-container': mermaid
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/03_security/security_threat_model.md`: Recommended section is missing for profile 'security-threat-model': miasi
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/04_quality/test_strategy.md`: Recommended section is missing for profile 'test-strategy': coverage
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/06_miasi/agent_card.md`: Recommended section is missing for profile 'miasi-agent-card': herramientas
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/06_miasi/tool_card.md`: Recommended section is missing for profile 'miasi-tool-card': aprobación
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/checklists/checklist_pre_code.md`: Recommended section is missing for profile 'generic-markdown': estado
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_audit_report.md`: Recommended section is missing for profile 'generic-markdown': propósito
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_audit_report.md`: Recommended section is missing for profile 'generic-markdown': estado
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_baseline_decision.md`: Recommended section is missing for profile 'generic-markdown': propósito
- **WARNING** `ARTIFACT_RECOMMENDED_SECTION_MISSING` — `docs/precode_baseline_decision.md`: Recommended section is missing for profile 'generic-markdown': estado

## Report Metadata

- `compatibility_boundary`: readiness_check legacy filename preserved
- `contract`: EvidenceReport
- `sprint`: FUNC-SPRINT-06
