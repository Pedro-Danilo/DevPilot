from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def _json(path: str) -> dict:
    return json.loads(_read(path))


def test_sprint_76_ci_artifacts_exist_and_are_synchronized() -> None:
    readme = _read("README.md")
    runbook = _read("docs/05_operations/runbook.md")
    backlog_g = _read("docs/devpilot_backlog_fase_G_productizacion_release.md")
    functional_backlog = _read("docs/functional_backlog_after_precode.md")

    for path in [
        ".github/workflows/devpilot-ci.yml",
        "docs/05_operations/ci_cd_local.md",
        "docs/audits/func_sprint_76_ci_scaffolding_audit.md",
        "docs/functional_sprint_76_manifest.json",
        "tests/test_ci_workflow_scaffolding.py",
        "tests/test_sprint_76_documentation.py",
    ]:
        assert (ROOT / path).exists(), path

    assert "FUNC-SPRINT-76 — CI local y workflow scaffolding" in readme
    assert "FUNC-SPRINT-76 — Operación de CI local y workflow scaffolding" in runbook
    assert 'phase_g_status: "closed"' in backlog_g


def test_sprint_76_docs_define_ci_boundaries() -> None:
    ci_doc = _read("docs/05_operations/ci_cd_local.md")
    audit = _read("docs/audits/func_sprint_76_ci_scaffolding_audit.md")
    workflow = _read(".github/workflows/devpilot-ci.yml")

    for text in [ci_doc, audit]:
        assert "quality-gate run --profile ci" in text
        assert "sin secretos" in text or "secrets.*" in text
        assert "no publica" in text
        assert "no despliega" in text
        assert "preliminar" in text or "primera versión" in text

    assert "quality-gate run --profile ci" in workflow
    assert "python -m pytest -q" in workflow
    assert "secrets." not in workflow.lower()


def test_sprint_76_manifest_declares_safe_ci_scope() -> None:
    manifest = _json("docs/functional_sprint_76_manifest.json")

    assert manifest["sprint"] == "FUNC-SPRINT-76"
    assert manifest["status"] == "implemented"
    assert manifest["phase"] == "FASE-G-PRODUCTIZACION-RELEASE"
    assert manifest["summary"]["fg_level"] == "FG-L2"
    assert manifest["summary"]["quality_gate_ci_profile_added"] is True
    assert manifest["summary"]["github_actions_scaffold_added"] is True
    assert manifest["summary"]["workflow_requires_secrets"] is False
    assert manifest["summary"]["workflow_publishes_artifacts"] is False
    assert manifest["summary"]["workflow_deploys"] is False
    assert manifest["summary"]["dependencies_added"] is False
    assert manifest["next_sprint"].startswith("FUNC-SPRINT-77")
