from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from devpilot_core.cli_models import ExitCode
from devpilot_core.quality import QualityGate, QualityGateOptions

ROOT = Path(__file__).resolve().parents[1]


def test_quality_gate_fast_profile_passes_and_reports_subgates() -> None:
    result = QualityGate(ROOT, options=QualityGateOptions(profile="fast")).run()

    assert result.ok is True
    assert result.exit_code == ExitCode.PASS
    summary = result.data["summary"]
    assert summary["profile"] == "fast"
    assert summary["subgates_total"] == 5
    assert summary["subgates_failed"] == 0
    assert summary["include_pytest"] is False
    assert summary["network_used"] is False
    assert summary["external_api_used"] is False
    assert summary["source_mutations_performed"] is False
    subgates = {item["id"]: item for item in result.data["subgates"]}
    for expected in ["readiness-strict", "standards-status", "miasi-validate", "eval-harness-ready", "app-contract"]:
        assert expected in subgates
        assert subgates[expected]["ok"] is True
        assert isinstance(subgates[expected]["duration_ms"], int)


def test_quality_gate_full_profile_adds_extended_local_subgates() -> None:
    result = QualityGate(ROOT, options=QualityGateOptions(profile="full")).run()

    assert result.ok is True
    subgate_ids = {item["id"] for item in result.data["subgates"]}
    assert "validation-gateway-all" in subgate_ids
    assert "visual-product-smoke" in subgate_ids
    assert "pytest" not in subgate_ids


def test_quality_gate_ci_profile_adds_workflow_static_subgate() -> None:
    result = QualityGate(ROOT, options=QualityGateOptions(profile="ci")).run()

    assert result.ok is True
    summary = result.data["summary"]
    assert summary["profile"] == "ci"
    assert summary["include_pytest"] is False
    subgate_ids = {item["id"] for item in result.data["subgates"]}
    for expected in ["validation-gateway-all", "visual-product-smoke", "ci-workflow-static"]:
        assert expected in subgate_ids
    assert "pytest" not in subgate_ids


def test_quality_gate_cli_json_and_report_output_are_parseable() -> None:
    completed = subprocess.run(
        [sys.executable, "-m", "devpilot_core", "quality-gate", "run", "--json", "--write-report"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )

    assert completed.returncode == 0, completed.stderr + completed.stdout
    payload = json.loads(completed.stdout)
    assert payload["command"] == "quality-gate run"
    assert payload["ok"] is True
    assert payload["data"]["summary"]["subgates_failed"] == 0
    reports = payload["data"].get("reports")
    assert reports["json"] == "outputs/reports/quality_gate.json"
    assert reports["markdown"] == "outputs/reports/quality_gate.md"
    assert (ROOT / reports["json"]).exists()
    assert (ROOT / reports["markdown"]).exists()


def test_quality_gate_rejects_unknown_profile() -> None:
    result = QualityGate(ROOT, options=QualityGateOptions(profile="unsafe")).run()

    assert result.ok is False
    assert result.exit_code == ExitCode.ERROR
    assert result.findings[0].id == "QUALITY_GATE_PROFILE_UNSUPPORTED"


def test_quality_gate_hardening_profile_includes_post_h_subgates() -> None:
    result = QualityGate(ROOT, options=QualityGateOptions(profile="hardening")).run()

    assert result.ok is True, result.to_dict()
    subgates = {item["id"]: item for item in result.data["subgates"]}
    assert "maturity-dashboard" in subgates
    assert "test-contract-registry-v2" in subgates
    assert "miasi-semantic-validate" in subgates
    assert "architecture-map" in subgates
    assert "docs-governance" in subgates
    assert "approval-rbac-hardening" in subgates
    assert subgates["miasi-semantic-validate"]["ok"] is True
    assert subgates["miasi-semantic-validate"]["summary"]["blocking_findings_total"] == 0
    assert subgates["architecture-map"]["ok"] is True
    assert subgates["architecture-map"]["summary"]["blocking_findings_total"] == 0
    assert subgates["docs-governance"]["ok"] is True
    assert subgates["docs-governance"]["summary"]["docs_governance_passed"] is True
    assert subgates["docs-governance"]["summary"]["blocking_findings_total"] == 0
    assert subgates["approval-rbac-hardening"]["ok"] is True
    assert subgates["approval-rbac-hardening"]["summary"]["quality_gate_ready"] is True
    assert subgates["approval-rbac-hardening"]["summary"]["blocking_findings_total"] == 0
    assert result.data["summary"]["subgates_passed"] == result.data["summary"]["subgates_total"]
