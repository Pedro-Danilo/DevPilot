from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_sprint_40_manifest_and_audit_exist() -> None:
    manifest = json.loads(_read("docs/functional_sprint_40_manifest.json"))
    audit = _read("docs/audits/func_sprint_40_patch_preflight_audit.md")

    assert manifest["sprint"] == "FUNC-SPRINT-40"
    assert manifest["status"] == "implemented"
    assert "src/devpilot_core/review/patch_preflight.py" in manifest["created_files"]
    assert "tests/test_patch_preflight.py" in manifest["tests"]
    assert ".devpilot/execution/command_allowlist.json" in manifest["modified_files"]
    assert "safe.patch" in manifest["modified_files"]
    assert manifest["architectural_decision"]["required"] is False
    assert "Patch preflight" in audit
    assert "git apply --check" in audit
    assert "no aplica" in audit


def test_sprint_40_readme_runbook_backlog_and_test_strategy_are_synchronized() -> None:
    readme = _read("README.md")
    runbook = _read("docs/05_operations/runbook.md")
    backlog = _read("docs/devpilot_backlog_fase_C_ingenieria_repositorio.md")
    test_strategy = _read("docs/04_quality/test_strategy.md")

    assert "## FUNC-SPRINT-40 — Patch preflight con verificación segura" in runbook
    assert "python -m devpilot_core patch check --patch-file safe.patch --json --write-report" in runbook
    assert 'phase_c_status: "completed"' in backlog
    assert "Estado de implementación Sprint 40" in backlog
    assert "Actualización FUNC-SPRINT-40 — Pruebas de Patch preflight seguro" in test_strategy


def test_sprint_40_miasi_patch_check_tool_and_allowlist_declared() -> None:
    registry = json.loads(_read(".devpilot/miasi/tool_registry.json"))
    agent_registry = json.loads(_read(".devpilot/miasi/agent_registry.json"))
    policy_matrix = json.loads(_read(".devpilot/miasi/policy_matrix.json"))
    allowlist = json.loads(_read(".devpilot/execution/command_allowlist.json"))
    tool_ids = {tool["tool_id"] for tool in registry["tools"]}
    rule_ids = {rule["rule_id"] for rule in policy_matrix["rules"]}
    command_ids = {command["command_id"] for command in allowlist["commands"]}
    tool_card = _read("docs/06_miasi/tool_card.md")
    tool_registry_doc = _read("docs/06_miasi/tool_registry.md")

    assert "patch.check" in tool_ids
    assert "PATCH_CHECK_DRY_RUN_ALLOW" in rule_ids
    assert "git.apply.check" in command_ids
    patch_agent = next(agent for agent in agent_registry["agents"] if agent["agent_id"] == "patch.review")
    assert "patch.check" in patch_agent["allowed_tools"]
    assert "Tool Card — Patch preflight seguro" in tool_card
    assert "Estado operacional Patch preflight" in tool_registry_doc


def test_sprint_40_functional_backlog_points_to_sprint_41_without_overclaiming() -> None:
    functional_backlog = _read("docs/functional_backlog_after_precode.md")
    safe_patch = _read("safe.patch")

    assert "Transición posterior a FUNC-SPRINT-40" in functional_backlog
    assert "no aplica patches" in functional_backlog
    assert "no ejecuta Git write" in functional_backlog
    assert "no modifica archivos" in functional_backlog
    assert "no crea sandbox ni ChangeSet todavía" in functional_backlog
    assert "safe patch preflight sample comment" in safe_patch
