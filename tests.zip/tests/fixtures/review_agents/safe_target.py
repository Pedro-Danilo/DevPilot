def value():
    return 'old'
